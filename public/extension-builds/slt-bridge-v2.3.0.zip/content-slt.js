/**
 * SLT-ERP Bridge v2.3.0 "AETHER-SCAN"
 * Engine: Semantic Tree-Walking & Matrix Alignment
 * Focus: High-Precision Node Extraction (Zero Mash Strategy)
 */

console.log('%c🌌 [SLT-AETHER-SCAN] v2.3.0 Engine Initialized', 'color: #8b5cf6; font-weight: bold; font-size: 14px;');

const VERSION = '2.3.0';

const AETHER_CONFIG = {
    INDICATORS: {
        CYAN: 'rgb(0, 202, 240)',
        BLUE: 'rgb(13, 202, 240)',
        HEX: '#0dcaf0'
    },
    JUNK: [/1769/i, /WELCOME/i, /LOGOUT/i, /WARNING/i, /CLICK HERE/i, /DASHBOARD/i],
    // Core Identity Concepts
    SCHEMA: ['RTOM', 'SERVICE ORDER', 'CIRCUIT', 'SERVICE', 'RECEIVED DATE', 'CUSTOMER NAME', 'CONTACT NO', 'ADDRESS', 'STATUS', 'PACKAGE', 'TEAM', 'SERIAL', 'ONT', 'IPTV', 'MATERIAL']
};

let MASTER_STORE = { so: '', tabs: {}, lastHash: '' };

const AetherUtils = {
    clean: (t) => t ? t.replace(/\s+/g, ' ').trim() : '',

    isLabel: (el) => {
        const style = window.getComputedStyle(el);
        const color = style.color;
        const isCyan = color === AETHER_CONFIG.INDICATORS.CYAN || color === AETHER_CONFIG.INDICATORS.BLUE || color.includes('0dcaf0');
        const isBold = parseInt(style.fontWeight) >= 600;
        const text = AetherUtils.clean(el.innerText || '');
        return (isCyan || (isBold && text.endsWith(':'))) && text.length > 1 && text.length < 50;
    },

    isJunk: (t) => {
        if (!t || t.length < 1) return true;
        return AETHER_CONFIG.JUNK.some(p => p.test(t));
    },

    getDeepText: (node) => {
        if (!node) return '';
        if (node.tagName === 'SELECT') return node.options[node.selectedIndex]?.text || '';
        if (node.tagName === 'INPUT' || node.tagName === 'TEXTAREA') return node.value || '';

        // Return text only from direct text nodes or simple spans to avoid mashing
        let text = '';
        node.childNodes.forEach(child => {
            if (child.nodeType === Node.TEXT_NODE) text += child.textContent;
            else if (['SPAN', 'B', 'STRONG', 'I', 'DIV'].includes(child.tagName)) {
                // Only take text if it's not another label
                if (!AetherUtils.isLabel(child)) text += child.innerText;
            }
        });
        return AetherUtils.clean(text);
    }
};

class AetherHarvester {
    static run() {
        const data = { details: {}, materials: [], visuals: [] };
        const activeTab = this.getTab();

        // 1. SEMANTIC MATRIX SCAN (For Grid-style Layouts)
        this.scanMatrix(data.details);

        // 2. TREE-WALKING PAIR DETECTION
        document.querySelectorAll('label, b, strong, th, span, div, td').forEach(el => {
            if (AetherUtils.isLabel(el)) {
                const k = AetherUtils.clean(el.innerText).replace(':', '').toUpperCase();
                if (data.details[k]) return; // Skip if already found by matrix scan

                let v = '';
                // Strategy A: Next Sibling Node Traversal
                let next = el.nextSibling;
                while (next && (next.nodeType === 3 && !next.textContent.trim() || (next.nodeType === 1 && AetherUtils.isLabel(next)))) {
                    next = next.nextSibling;
                }

                if (next) {
                    v = next.nodeType === 1 ? AetherUtils.getDeepText(next) : AetherUtils.clean(next.textContent);
                }

                // Strategy B: Ancestor Search (For TD/COL based pairings)
                if (!v || v === k) {
                    const parentTd = el.closest('td');
                    if (parentTd?.nextElementSibling) {
                        v = AetherUtils.getDeepText(parentTd.nextElementSibling);
                    } else {
                        const parentCol = el.closest('[class*="col-"]');
                        if (parentCol?.nextElementSibling) v = AetherUtils.getDeepText(parentCol.nextElementSibling);
                    }
                }

                if (v && v !== k && !AetherUtils.isJunk(v)) {
                    data.details[k] = v;
                }
            }
        });

        // 3. TABLE INDEXER (Materials & Serials)
        document.querySelectorAll('table').forEach(table => {
            const rows = Array.from(table.querySelectorAll('tr'));
            if (rows.length < 2) return;
            const headers = Array.from(rows[0].querySelectorAll('td, th')).map(c => AetherUtils.clean(c.innerText).toUpperCase());

            const itemIdx = headers.findIndex(h => h.includes('ITEM') || h.includes('DESCRIPTION') || h.includes('ATTRIBUTE'));
            const valIdx = headers.findIndex(h => h.includes('QTY') || h.includes('QUANTITY') || h.includes('SERIAL') || h.includes('VALUE') || h.includes('DEFAULT'));

            if (itemIdx !== -1 && valIdx !== -1) {
                rows.forEach((r, idx) => {
                    if (idx === 0) return;
                    const cells = Array.from(r.querySelectorAll('td, th'));
                    if (cells.length > Math.max(itemIdx, valIdx)) {
                        const k = AetherUtils.clean(cells[itemIdx].innerText);
                        const v = AetherUtils.clean(cells[valIdx].innerText);
                        if (k && v && !AetherUtils.isJunk(k)) {
                            if (headers[itemIdx].includes('ITEM')) data.materials.push({ ITEM: 'MATERIAL', TYPE: k, QTY: v });
                            else data.details[k.toUpperCase()] = v;
                        }
                    }
                });
            }
        });

        // 4. VISUAL ASSET CRAWLER
        if (activeTab.includes('IMAGE') || activeTab.includes('PHOTO')) {
            document.querySelectorAll('img').forEach(img => {
                const src = img.src || img.dataset.src || img.getAttribute('src');
                if (src && src.startsWith('http') && !src.includes('no-image')) {
                    data.visuals.push({ url: src, alt: img.alt || 'Asset' });
                }
            });
        }

        return data;
    }

    static scanMatrix(details) {
        // Special Matrix Detection: Row 1 Labels, Row 2 Values
        document.querySelectorAll('tr, .row').forEach(container => {
            const labels = Array.from(container.querySelectorAll('*')).filter(el => AetherUtils.isLabel(el));
            if (labels.length > 2) {
                // Check next row/sibling for values
                const nextRow = container.nextElementSibling;
                if (nextRow) {
                    const values = Array.from(nextRow.querySelectorAll('td, .col-sm-3, .col-md-3'));
                    if (values.length >= labels.length) {
                        labels.forEach((l, i) => {
                            const k = AetherUtils.clean(l.innerText).toUpperCase();
                            const v = AetherUtils.getDeepText(values[i]);
                            if (k && v && v !== k && !AetherUtils.isJunk(v)) details[k] = v;
                        });
                    }
                }
            }
        });
    }

    static getTab() {
        const el = document.querySelector('.nav-tabs .nav-link.active') || document.querySelector('.active a') || { innerText: 'GENERAL' };
        return AetherUtils.clean(el.innerText).toUpperCase();
    }
}

async function runAether() {
    if (!chrome.runtime?.id) return;
    const url = window.location.href;
    const soMatch = url.match(/[?&]sod=([A-Z0-9]+)/i);
    const so = soMatch ? soMatch[1].toUpperCase() : '';
    if (!so) return;

    if (so !== MASTER_STORE.so) {
        const saved = await new Promise(r => chrome.storage.local.get([`sod_${so}`], r));
        MASTER_STORE.so = so;
        MASTER_STORE.tabs = saved[`sod_${so}`] || {};
    }

    const currentTab = AetherHarvester.getTab();
    const result = AetherHarvester.run();

    // Additive Smart Merge
    if (Object.keys(result.details).length > 0) {
        MASTER_STORE.tabs[currentTab] = { ...(MASTER_STORE.tabs[currentTab] || {}), ...result.details };
    }

    const payload = {
        url: url,
        soNum: so,
        activeTab: currentTab,
        timestamp: new Date().toISOString(),
        details: result.details,
        allTabs: MASTER_STORE.tabs,
        teamDetails: { 'SELECTED TEAM': AetherUtils.clean(document.querySelector('#mobusr option:checked')?.text || "") },
        materialDetails: result.materials,
        visualDetails: result.visuals,
        currentUser: AetherUtils.clean(document.querySelector('.user-profile-dropdown h6')?.innerText || "").replace("Welcome, ", "")
    };

    const hash = btoa(JSON.stringify(payload.allTabs)).substring(0, 32);
    if (hash !== MASTER_STORE.lastHash) {
        MASTER_STORE.lastHash = hash;
        chrome.storage.local.set({ lastScraped: payload, [`sod_${so}`]: MASTER_STORE.tabs });
        chrome.runtime.sendMessage({ action: 'pushToERP', data: payload });
    }
}

// Reactive Observer
new MutationObserver(() => runAether()).observe(document.body, { childList: true, subtree: true, characterData: true });

// UI HUD
if (!document.getElementById('aether-hud')) {
    const hud = document.createElement('div');
    hud.id = 'aether-hud';
    hud.style.cssText = `position: fixed; top: 10px; right: 20px; z-index: 999999; background: rgba(15, 23, 42, 0.9); backdrop-filter: blur(4px); color: #8b5cf6; padding: 8px 16px; border-radius: 12px; font-family: 'Inter', sans-serif; font-size: 11px; font-weight: 800; border: 1px solid #8b5cf6; box-shadow: 0 0 20px rgba(139, 92, 246, 0.3); pointer-events: none;`;
    hud.innerHTML = `AETHER-SCAN v${VERSION}`;
    document.body.appendChild(hud);
}

runAether();
setInterval(runAether, 4000);
