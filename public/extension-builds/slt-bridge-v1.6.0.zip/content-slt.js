// SLT-ERP Bridge Extension v1.6.0 (The Ultimate Scraper)
// Powered by Structural Mapping & Mutation Observation
console.log('🚀 [SLT-BRIDGE] Ultimate Scraper v1.6.0 starting...');

const CURRENT_VERSION = '1.6.0';

// --- 1. MAPPING CONFIGURATION (Modify these if portal changes) ---
const CONFIG = {
    SELECTORS: {
        USER_PROFILE: '.user-profile-dropdown h6',
        ACTIVE_TAB: '.nav-tabs .nav-link.active',
        TEAM_DROPDOWN: '#mobusr',
        HIDDEN_INPUTS: ['iptv1', 'iptv2', 'iptv3', 'bb', 'voice2', 'sval']
    },
    TABLE_HEADERS: {
        ATTRIBUTE: ['ATTRIBUTE NAME', 'ITEM', 'COMPONENT', 'PARAMETER'],
        VALUE: ['DEFAULT VALUE', 'VALUE', 'QTY', 'QUANTITY', 'SERIAL NUMBER']
    },
    // Priority labels for the Universal Scraper
    LABELS: [
        'RECEIVED DATE', 'RTOM', 'TASK', 'STATUS', 'ADDRESS', 'CUSTOMER NAME',
        'ORDER TYPE', 'SERVICE TYPE', 'PACKAGE', 'SERVICE ORDER', 'SOD',
        'STATUS DATE', 'EQUIPMENT CLASS', 'CONTACT NO', 'CIRCUIT', 'LINE TYPE',
        'TEST TYPE', 'MOBILE TEAM', 'DEFAULT VALUE', 'ONT_ROUTER_SERIAL_NUMBER',
        'OLT MANUFACTURER', 'DESCRIPTION'
    ]
};

let lastPushedHash = "";
let sodCache = { soNum: '', tabs: {} };

// --- 2. UTILITY FUNCTIONS ---

const clean = (txt) => txt ? txt.replace(/\s+/g, ' ').trim() : '';

function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    return style.display !== 'none' && style.visibility !== 'hidden' && !!(el.offsetWidth || el.offsetHeight);
}

const isCyanish = (color) => {
    if (!color) return false;
    if (color === 'rgb(13, 202, 240)' || color === 'rgb(0, 202, 240)' || color.includes('0dcaf0')) return true;
    const m = color.match(/\d+/g);
    if (m && m.length >= 3) {
        const r = parseInt(m[0]), g = parseInt(m[1]), b = parseInt(m[2]);
        // Precise Cyan filter
        return g > 140 && b > 140 && r < 140;
    }
    return false;
};

// --- 3. CORE SCRAPING LOGIC ---

async function scrape() {
    if (!chrome.runtime?.id) return;

    const url = window.location.href;
    const sodMatch = url.match(/[?&]sod=([A-Z0-9]+)/i);
    const soNum = (sodMatch ? sodMatch[1].toUpperCase() : '').trim();

    // Accumulation Persistence
    if (soNum && soNum !== sodCache.soNum) {
        sodCache.soNum = soNum;
        const result = await new Promise(r => chrome.storage.local.get([`sod_${soNum}`], r));
        sodCache.tabs = result[`sod_${soNum}`] || {};
    }

    const activeTabEl = document.querySelector(CONFIG.SELECTORS.ACTIVE_TAB);
    const activeTab = activeTabEl ? clean(activeTabEl.innerText).toUpperCase() : 'GENERAL';

    const data = {
        url: url,
        soNum: soNum,
        activeTab: activeTab,
        timestamp: new Date().toISOString(),
        details: {},
        allTabs: sodCache.tabs,
        teamDetails: {},
        materialDetails: [],
        hiddenInfo: {},
        currentUser: ''
    };

    const addDetail = (key, val) => {
        if (!key || !val || val === '0' || val.toUpperCase().includes('SELECT MATERIAL')) return;
        key = key.replace(':', '').trim().toUpperCase();
        if (key.length < 2 || /^[0-9]+$/.test(key)) return;

        if (data.details[key]) {
            if (data.details[key] === val) return;
            if (Array.isArray(data.details[key])) {
                if (!data.details[key].includes(val)) data.details[key].push(val);
            } else {
                data.details[key] = [data.details[key], val];
            }
        } else {
            data.details[key] = val;
        }
    };

    // PHASE A: Structural Meta Scrape
    const userEl = document.querySelector(CONFIG.SELECTORS.USER_PROFILE);
    if (userEl) data.currentUser = clean(userEl.innerText).replace('Welcome, ', '');

    const teamEl = document.querySelector(CONFIG.SELECTORS.TEAM_DROPDOWN);
    if (teamEl && !teamEl.value.includes('-- Select Team --')) {
        data.teamDetails['SELECTED TEAM'] = teamEl.options[teamEl.selectedIndex]?.text || '';
    }

    CONFIG.SELECTORS.HIDDEN_INPUTS.forEach(id => {
        const el = document.getElementById(id);
        if (el) data.hiddenInfo[id.toUpperCase()] = el.value || '';
    });

    // PHASE B: Advanced Table Indexing Scrape
    document.querySelectorAll('table').forEach(table => {
        if (!isVisible(table)) return;
        const rows = Array.from(table.querySelectorAll('tr'));
        if (rows.length === 0) return;

        // Find header indices
        const headers = Array.from(rows[0].querySelectorAll('th, td')).map(c => clean(c.innerText).toUpperCase());
        const attrIdx = headers.findIndex(h => CONFIG.TABLE_HEADERS.ATTRIBUTE.some(k => h.includes(k)));
        const valIdx = headers.findIndex(h => CONFIG.TABLE_HEADERS.VALUE.some(k => h.includes(k)));

        rows.forEach((row, rIdx) => {
            const cells = Array.from(row.querySelectorAll('td, th'));
            if (cells.length < 2) return;

            // Header-Value Grid Scrape
            if (attrIdx !== -1 && valIdx !== -1 && rIdx > 0) {
                const k = clean(cells[attrIdx].innerText);
                const v = clean(cells[valIdx].innerText);
                if (k && v && !headers.includes(k.toUpperCase())) addDetail(k, v);
            }
            // 2-Column Vertical Table Scrape
            else if (cells.length === 2 && !headers.includes(clean(cells[0].innerText).toUpperCase())) {
                const k = clean(cells[0].innerText);
                const v = clean(cells[1].innerText);
                if (k && v && v !== k) addDetail(k, v);
            }
        });

        // Special Phase: Materials (Items & Qty)
        if (headers.some(h => h.includes('ITEM')) && headers.some(h => h.includes('QTY'))) {
            const itemIdx = headers.findIndex(h => h.includes('ITEM'));
            const qtyIdx = headers.findIndex(h => h.includes('QTY') || h.includes('QUANTITY'));
            rows.forEach((row, rIdx) => {
                if (rIdx === 0) return;
                const tds = row.querySelectorAll('td');
                if (tds.length > Math.max(itemIdx, qtyIdx)) {
                    const item = clean(tds[itemIdx].innerText);
                    const qty = clean(tds[qtyIdx].innerText);
                    if (item && qty && !item.toUpperCase().includes('ITEM')) {
                        data.materialDetails.push({ ITEM: 'MATERIAL', TYPE: item, QTY: qty });
                    }
                }
            });
        }
    });

    // PHASE C: Universal Smart Scrape (Form Fields & Labels)
    document.querySelectorAll('label, b, strong, span, th, td, div').forEach(el => {
        if (!isVisible(el)) return;
        const style = window.getComputedStyle(el);
        const text = clean(el.innerText);
        if (!text || text.length > 60) return;

        // Identify labels (Cyan or Bold with Colon)
        if (isCyanish(style.color) || (style.fontWeight >= 700 && text.endsWith(':'))) {
            let val = '';
            let next = el.nextElementSibling || el.nextSibling;
            // Skip whitespace text nodes
            while (next && next.nodeType === 3 && !next.textContent.trim()) next = next.nextSibling;

            if (next) {
                if (next.tagName === 'SELECT') {
                    val = next.options[next.selectedIndex]?.text || '';
                } else if (next.tagName === 'INPUT' || next.tagName === 'TEXTAREA') {
                    val = next.value || '';
                } else {
                    const nStyle = next.nodeType === 1 ? window.getComputedStyle(next) : null;
                    if (!nStyle || !isCyanish(nStyle.color)) {
                        val = clean(next.textContent || next.innerText);
                    }
                }
            }

            if (val && val !== text && val.length < 1000) {
                // Correct for "Contaminated" values (Shifted data)
                let wasShifted = false;
                for (const pk of CONFIG.LABELS) {
                    if (val.toUpperCase().startsWith(pk) && text.toUpperCase() !== pk) {
                        addDetail(pk, val.substring(pk.length).trim());
                        wasShifted = true;
                    }
                }
                if (!wasShifted) addDetail(text, val);
            }
        }
    });

    // Final Sync
    if (data.soNum && (Object.keys(data.details).length > 2 || data.materialDetails.length > 0)) {
        sodCache.tabs[data.activeTab] = JSON.parse(JSON.stringify(data.details));
        chrome.storage.local.set({ [`sod_${soNum}`]: sodCache.tabs });
    }

    chrome.storage.local.set({ lastScraped: data });

    // Server Sync
    if (data.soNum) {
        if (data.activeTab === 'IMAGES' || data.activeTab === 'PHOTOS') return data;
        const hash = JSON.stringify({ so: data.soNum, tabs: data.allTabs, materials: data.materialDetails });
        if (hash !== lastPushedHash) {
            chrome.runtime.sendMessage({ action: 'pushToERP', data }, (res) => {
                if (!chrome.runtime.lastError && res?.success) {
                    lastPushedHash = hash;
                    updateIndicator('SYNC OK', '#22c55e');
                } else {
                    updateIndicator('BRIDGE ERROR', '#ef4444');
                }
            });
        }
    }
    return data;
}

// --- 4. ENGINE: Mutation Observer & Interceptors ---

// Trigger scraping when DOM changes (tab switches, loading finishes)
const observer = new MutationObserver((mutations) => {
    let shouldScrape = false;
    for (const m of mutations) {
        if (m.type === 'childList' && m.addedNodes.length > 0) {
            shouldScrape = true;
            break;
        }
    }
    if (shouldScrape) scrape();
});

observer.observe(document.body, { childList: true, subtree: true });

// Initial & Periodic Runs
if (!document.getElementById('slt-erp-indicator')) {
    const b = document.createElement('div');
    b.id = 'slt-erp-indicator';
    b.style.cssText = `position: fixed; top: 10px; right: 20px; z-index: 2147483647; background: #0f172a; color: #fff; padding: 6px 14px; font-size: 11px; font-weight: 600; border-radius: 8px; display: flex; align-items: center; gap: 8px; pointer-events: none;`;
    b.innerHTML = `<div style="width: 8px; height: 8px; border-radius: 50%; background: #22c55e;" id="slt-erp-status-dot"></div><span id="slt-erp-status-tag">SLT BRIDGE v${CURRENT_VERSION}</span>`;
    document.body.appendChild(b);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getPortalData") {
        scrape().then(res => sendResponse(res));
    }
    return true;
});

setInterval(scrape, 3000);
scrape();
function updateIndicator(status, color) {
    const tag = document.getElementById('slt-erp-status-tag');
    const dot = document.getElementById('slt-erp-status-dot');
    if (tag && dot) {
        tag.textContent = status;
        dot.style.background = color;
        dot.style.boxShadow = `0 0 8px ${color}`;
    }
}
