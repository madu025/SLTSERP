/**
 * ERP INJECTOR (content-main.js)
 * World: MAIN
 * Role: Receives data and fills inputs in the ERP System
 */

console.log('🖊️ [ERP-INJECTOR] Main World Loaded.');

window.addEventListener('message', (event) => {
    // Security check: ensure message is from our extension
    if (event.source !== window) return;

    if (event.data.type && event.data.type === 'FROM_ULTRON_BRIDGE') {
        const data = event.data.payload;
        console.log('%c📥 [ERP-INJECTOR] Received Data for SO:', 'color: #3b82f6; font-size: 12px;', data.soNum);

        autoFillERP(data);
    }
});

function autoFillERP(data) {
    const details = data.details || {};

    // Iterate over scraped keys (e.g., "CUSTOMER NAME", "REGION")
    Object.keys(details).forEach(key => {
        const value = details[key];
        if (!value) return;

        // 1. Try to find input by exact ID (e.g., <input id="customer_name">)
        const idCandidate = document.getElementById(key.toLowerCase().replace(/\s/g, '_'));
        if (idCandidate) {
            fillElement(idCandidate, value);
            return;
        }

        // 2. Try to find input by exact NAME attribute
        const nameCandidate = document.querySelector(`input[name="${key}"]`);
        if (nameCandidate) {
            fillElement(nameCandidate, value);
            return;
        }

        // 3. HEURISTIC SEARCH (The Smart Way)
        // Look for a LABEL with text matching our Key
        const labels = Array.from(document.querySelectorAll('label, span, div'));
        const targetLabel = labels.find(l => l.innerText.toUpperCase() === key);

        if (targetLabel) {
            // Find the input associated with this label
            // Usually right after the label, or via 'for' attribute
            let input = document.getElementById(targetLabel.getAttribute('for'));

            if (!input) {
                // Check next sibling or parent container
                const parent = targetLabel.closest('div') || targetLabel.parentElement;
                input = parent.querySelector('input, select, textarea');
            }

            if (input) {
                fillElement(input, value);
            }
        }
    });
}

function fillElement(element, value) {
    // Only fill if empty to avoid overwriting user edits
    if ((element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') && !element.value) {
        element.value = value;
        // Trigger React/Vue change events
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
        console.log(`%c✅ Filled:`, 'color: #10b981;', element, value);
    } else if (element.tagName === 'SELECT') {
        // Try to match option text
        Array.from(element.options).forEach(opt => {
            if (opt.text === value) element.selectedIndex = opt.index;
        });
        element.dispatchEvent(new Event('change', { bubbles: true }));
    }
}