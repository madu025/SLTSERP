/**
 * SLT-ERP PHOENIX BRIDGE v3.0.0
 * Engine: Semantic Discovery & Multi-Layer Persistence
 */

console.log('%c🔥 [PHOENIX-RISE] v3.0.0 Online', 'color: #ff4d4d; font-weight: bold; font-size: 16px;');

const PHOENIX_CONFIG = {
    INDICATORS: {
        CYAN: ['rgb(0, 202, 240)', 'rgb(13, 202, 240)', '#0dcaf0'],
        LABELS: ['RTOM', 'SERVICE ORDER', 'CIRCUIT', 'SERVICE', 'RECEIVED DATE', 'CUSTOMER NAME', 'CONTACT NO', 'ADDRESS', 'STATUS', 'PACKAGE', 'TEAM', 'SERIAL', 'ONT', 'IPTV', 'MATERIAL']
    },
    JUNK: [/1769/i, /WELCOME/i, /LOGOUT/i, /WARNING/i, /DASHBOARD/i]
};

let CORE_STATE = { so: '', tabs: {}, lastHash: '' };

const PhoenixUtils = {
    clean: t => t ? t.replace(/\s+/g, ' ').trim() : '',

    isLabel: el => {
        const style = window.getComputedStyle(el);
        const color = style.color;
        if (!color) return false;

        let isCyan = PHOENIX_CONFIG.INDICATORS.CYAN.some(c => color === c || color.includes('0dcaf0'));

        // Robust Range Check
        const m = color.match(/\d+/g);
        if (m && m.length >= 3) {
            const r = parseInt(m[0]), g = parseInt(m[1]), b = parseInt(m[2]);
            if (g > 130 && b > 130 && r < 160) isCyan = true;
        }

        const isBold = parseInt(style.fontWeight) >= 600;
        const text = PhoenixUtils.clean(el.innerText || '');
        return (isCyan || (isBold && text.endsWith(':'))) && text.length > 1 && text.length < 50;
    },

    getValue: el => {
        if (!el) return '';
        if (el.tagName === 'SELECT') return el.options[el.selectedIndex]?.text || '';
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return el.value || '';
        const inner = el.querySelector('input, select');
        if (inner) return PhoenixUtils.getValue(inner);
        return PhoenixUtils.clean(el.innerText || el.textContent);
    }
};

class PhoenixEngine {
    static async capture() {
        const data = { details: {}, materials: [], visuals: [] };
        const activeTab = this.getTab();

        // Layer 1: Global Semantic Scan
        document.querySelectorAll('label, b, strong, th, span, td, div').forEach(el => {
            if (PhoenixUtils.isLabel(el)) {
                const k = PhoenixUtils.clean(el.innerText).replace(':', '').toUpperCase();
                let v = '';

                // Proximity search
                let next = el.nextElementSibling || el.nextSibling;
                while (next && (next.nodeType === 3 && !next.textContent.trim())) next = next.nextSibling;
                if (next) v = PhoenixUtils.getValue(next);

                // Grid fallback
                if (!v || v === k) {
                    const td = el.closest('td');
                    if (td?.nextElementSibling) v = PhoenixUtils.getValue(td.nextElementSibling);
                }

                if (v && v !== k && !PHOENIX_CONFIG.JUNK.some(p => p.test(v))) {
                    data.details[k] = v;
                }
            }
        });

        // Layer 2: Matrix Table Recovery (Materials & Serials)
        document.querySelectorAll('table').forEach(table => {
            const rows = Array.from(table.querySelectorAll('tr'));
            if (rows.length < 2) return;
            const headers = Array.from(rows[0].querySelectorAll('td, th')).map(c => PhoenixUtils.clean(c.innerText).toUpperCase());

            rows.forEach((r, idx) => {
                const cells = Array.from(r.querySelectorAll('td, th'));
                if (cells.length < 2) return;

                const itmIdx = headers.findIndex(h => h.includes('ITEM') || h.includes('ATTRIBUTE') || h.includes('DESCRIPTION'));
                const valIdx = headers.findIndex(h => h.includes('QTY') || h.includes('VALUE') || h.includes('SERIAL') || h.includes('DEFAULT'));

                if (itmIdx !== -1 && valIdx !== -1 && idx > 0 && cells.length > Math.max(itmIdx, valIdx)) {
                    const k = PhoenixUtils.clean(cells[itmIdx].innerText);
                    const v = PhoenixUtils.getValue(cells[valIdx]);
                    if (k && v && !PHOENIX_CONFIG.JUNK.some(p => p.test(k))) {
                        if (headers[itmIdx].includes('ITEM')) data.materials.push({ ITEM: 'MATERIAL', TYPE: k, QTY: v });
                        else data.details[k.toUpperCase()] = v;
                    }
                } else if (cells.length === 2 && idx > 0) {
                    const k = PhoenixUtils.clean(cells[0].innerText).toUpperCase();
                    const v = PhoenixUtils.getValue(cells[1]);
                    if (k && v && v !== k && !PHOENIX_CONFIG.JUNK.some(p => p.test(k))) data.details[k] = v;
                }
            });
        });

        // Layer 3: Image Synthesis
        if (activeTab.includes('IMAGE') || activeTab.includes('PHOTO')) {
            document.querySelectorAll('img').forEach(img => {
                const src = img.src || img.dataset.src;
                if (src && src.startsWith('http')) data.visuals.push({ url: src, alt: img.alt });
            });
        }

        return data;
    }

    static getTab() {
        const el = document.querySelector('.nav-tabs .nav-link.active') || document.querySelector('.active a');
        return el ? PhoenixUtils.clean(el.innerText).toUpperCase() : 'GENERAL';
    }
}

async function phoenixPulse() {
    if (!chrome.runtime?.id) return;
    const so = (window.location.href.match(/[?&]sod=([A-Z0-9]+)/i) || [])[1]?.toUpperCase();
    if (!so) return;

    if (so !== CORE_STATE.so) {
        const saved = await new Promise(r => chrome.storage.local.get([`sod_${so}`], r));
        CORE_STATE.so = so;
        CORE_STATE.tabs = saved[`sod_${so}`] || {};
    }

    const currentTab = PhoenixEngine.getTab();
    const result = await PhoenixEngine.capture();

    if (Object.keys(result.details).length > 0) {
        CORE_STATE.tabs[currentTab] = { ...(CORE_STATE.tabs[currentTab] || {}), ...result.details };
        if (result.visuals.length > 0) {
            if (!CORE_STATE.tabs['GALLERY']) CORE_STATE.tabs['GALLERY'] = [];
            result.visuals.forEach(v => {
                if (!CORE_STATE.tabs['GALLERY'].find(x => x.url === v.url)) CORE_STATE.tabs['GALLERY'].push(v);
            });
        }
    }

    const payload = {
        url: window.location.href,
        soNum: so,
        activeTab: currentTab,
        timestamp: new Date().toISOString(),
        details: result.details,
        allTabs: CORE_STATE.tabs,
        teamDetails: { 'SELECTED TEAM': PhoenixUtils.getValue(document.querySelector('#mobusr')) },
        materialDetails: result.materials,
        visualDetails: result.visuals,
        currentUser: PhoenixUtils.clean(document.querySelector('.user-profile-dropdown h6')?.innerText || "").replace("Welcome, ", "")
    };

    const hash = btoa(JSON.stringify(payload.allTabs) + JSON.stringify(payload.materialDetails)).substring(0, 32);
    if (hash !== CORE_STATE.lastHash) {
        CORE_STATE.lastHash = hash;
        chrome.storage.local.set({ lastScraped: payload, [`sod_${so}`]: CORE_STATE.tabs });
        chrome.runtime.sendMessage({ action: 'pushToERP', data: payload });
    }
}

new MutationObserver(() => phoenixPulse()).observe(document.body, { childList: true, subtree: true });
setInterval(phoenixPulse, 3000);
phoenixPulse();