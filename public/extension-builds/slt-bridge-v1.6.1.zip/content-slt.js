// SLT-ERP Bridge Extension v1.6.1 (The Fixed Version)
// Focus: Container Isolation & Async Robustness
console.log('🚀 [SLT-BRIDGE] Scraper v1.6.1 starting...');

const CURRENT_VERSION = '1.6.1';

// --- 1. MAPPING CONFIGURATION ---
const CONFIG = {
    SELECTORS: {
        MAIN_CONTENT: '.main-panel, #main-content, .content-wrapper, .wrapper', // Portal content area
        USER_PROFILE: '.user-profile-dropdown h6',
        ACTIVE_TAB: '.nav-tabs .nav-link.active',
        TEAM_DROPDOWN: '#mobusr',
        HIDDEN_INPUTS: ['iptv1', 'iptv2', 'iptv3', 'bb', 'voice2', 'sval']
    },
    TABLE_HEADERS: {
        ATTRIBUTE: ['ATTRIBUTE NAME', 'ITEM', 'COMPONENT', 'PARAMETER'],
        VALUE: ['DEFAULT VALUE', 'VALUE', 'QTY', 'QUANTITY', 'SERIAL NUMBER']
    },
    JUNK_KEYS: [
        'WELCOME', 'LOGOUT', 'WARNING', 'CONNECTION DETAIL', 'LATEST', 'HOME',
        'DASHBOARD', 'SEARCH', 'REFRESH', 'PROFILE', 'SETTINGS', 'PENDING IMAGES'
    ],
    LABELS: [
        'RECEIVED DATE', 'RTOM', 'TASK', 'STATUS', 'ADDRESS', 'CUSTOMER NAME',
        'ORDER TYPE', 'SERVICE TYPE', 'PACKAGE', 'SERVICE ORDER', 'SOD',
        'STATUS DATE', 'EQUIPMENT CLASS', 'CONTACT NO', 'CIRCUIT', 'LINE TYPE',
        'TEST TYPE', 'MOBILE TEAM', 'DEFAULT VALUE', 'ONT_ROUTER_SERIAL_NUMBER',
        'OLT MANUFACTURER', 'DESCRIPTION'
    ]
};

let lastPushedHash = "";
let sodCache = { soNum: '', tabs: {} };
let isScraping = false;

// --- 2. UTILITY FUNCTIONS ---

const clean = (txt) => txt ? txt.replace(/\s+/g, ' ').trim() : '';

function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
}

const isCyanish = (color) => {
    if (!color) return false;
    if (color === 'rgb(13, 202, 240)' || color === 'rgb(0, 202, 240)' || color.includes('0dcaf0')) return true;
    const m = color.match(/\d+/g);
    if (m && m.length >= 3) {
        const r = parseInt(m[0]), g = parseInt(m[1]), b = parseInt(m[2]);
        // Inclusive Cyan/Blue filter
        return g > 130 && b > 130 && r < 160;
    }
    return false;
};

// --- 3. CORE SCRAPING ENGINE ---

async function scrape() {
    if (isScraping || !chrome.runtime?.id) return;
    isScraping = true;

    try {
        const url = window.location.href;
        const sodMatch = url.match(/[?&]sod=([A-Z0-9]+)/i);
        const soNum = (sodMatch ? sodMatch[1].toUpperCase() : '').trim();

        if (!soNum) {
            isScraping = false;
            return null;
        }

        // 1. Sync Cache with Storage
        if (soNum !== sodCache.soNum) {
            const result = await new Promise(r => chrome.storage.local.get([`sod_${soNum}`], r));
            sodCache.soNum = soNum;
            sodCache.tabs = result[`sod_${soNum}`] || {};
        }

        const activeTabEl = document.querySelector(CONFIG.SELECTORS.ACTIVE_TAB);
        const activeTab = activeTabEl ? clean(activeTabEl.innerText).toUpperCase() : 'GENERAL';

        const data = {
            url: url,
            soNum: soNum,
            activeTab: activeTab,
            timestamp: new Date().toISOString(),
            details: {},
            allTabs: sodCache.tabs, // Start with existing cache
            teamDetails: {},
            materialDetails: [],
            hiddenInfo: {},
            currentUser: ''
        };

        const addDetail = (key, val) => {
            if (!key || !val || val === '0' || val.toUpperCase().includes('SELECT MATERIAL')) return;
            key = key.replace(':', '').replace(',', '').trim().toUpperCase();

            // Filter Junk
            if (CONFIG.JUNK_KEYS.some(jk => key.includes(jk))) return;
            if (key.length < 2 || /^[0-9]+$/.test(key)) return;

            if (data.details[key]) {
                if (data.details[key] === val) return;
                if (Array.isArray(data.details[key])) {
                    if (!data.details[key].includes(val)) data.details[key].push(val);
                } else {
                    data.details[key] = [data.details[key], val];
                }
            } else {
                data.details[key] = val;
            }
        };

        // Locate Main Content Container
        const mainContent = document.querySelector(CONFIG.SELECTORS.MAIN_CONTENT) || document.body;

        // PHASE A: Form Meta (Dropdowns & Inputs)
        mainContent.querySelectorAll('input, select, textarea').forEach(el => {
            if (!isVisible(el)) return;
            let label = '';
            const prev = el.previousElementSibling;
            if (prev && (prev.tagName === 'LABEL' || isCyanish(window.getComputedStyle(prev).color))) {
                label = prev.innerText;
            }
            if (!label) {
                const parent = el.closest('div, td');
                const l = parent?.querySelector('label') || parent?.previousElementSibling?.querySelector('label');
                if (l) label = l.innerText;
            }
            const val = el.tagName === 'SELECT' ? el.options[el.selectedIndex]?.text : el.value;
            if (label && val && val !== '0') addDetail(label, val);
        });

        // PHASE B: Advanced Table Indexing
        mainContent.querySelectorAll('table').forEach(table => {
            if (!isVisible(table)) return;
            const rows = Array.from(table.querySelectorAll('tr'));
            if (rows.length === 0) return;

            const headers = Array.from(rows[0].querySelectorAll('th, td')).map(c => clean(c.innerText).toUpperCase());
            const attrIdx = headers.findIndex(h => CONFIG.TABLE_HEADERS.ATTRIBUTE.some(k => h.includes(k)));
            const valIdx = headers.findIndex(h => CONFIG.TABLE_HEADERS.VALUE.some(k => h.includes(k)));

            rows.forEach((row, rIdx) => {
                const cells = Array.from(row.querySelectorAll('td, th'));
                if (cells.length < 2) return;

                if (attrIdx !== -1 && valIdx !== -1 && rIdx > 0) {
                    const k = clean(cells[attrIdx].innerText);
                    const v = clean(cells[valIdx].innerText);
                    if (k && v && !headers.includes(k.toUpperCase())) addDetail(k, v);
                } else if (cells.length === 2 && !headers.includes(clean(cells[0].innerText).toUpperCase())) {
                    const k = clean(cells[0].innerText);
                    const v = clean(cells[1].innerText);
                    if (k && v && v !== k) addDetail(k, v);
                }
            });

            // Materials Special Extract
            if (headers.some(h => h.includes('ITEM')) && (headers.some(h => h.includes('QTY')) || headers.some(h => h.includes('SERIAL')))) {
                const itemIdx = headers.findIndex(h => h.includes('ITEM'));
                const qtyIdx = headers.findIndex(h => h.includes('QTY') || h.includes('QUANTITY') || h.includes('SERIAL'));
                rows.forEach((row, rIdx) => {
                    if (rIdx === 0) return;
                    const tds = row.querySelectorAll('td');
                    if (tds.length > Math.max(itemIdx, qtyIdx)) {
                        const item = clean(tds[itemIdx].innerText);
                        const qty = clean(tds[qtyIdx].innerText);
                        if (item && qty && !item.toUpperCase().includes('ITEM')) {
                            data.materialDetails.push({ ITEM: 'MATERIAL', TYPE: item, QTY: qty });
                        }
                    }
                });
            }
        });

        // PHASE C: Universal Label Scraper
        mainContent.querySelectorAll('label, b, strong, span, th, td, div').forEach(el => {
            if (!isVisible(el)) return;
            const style = window.getComputedStyle(el);
            const text = clean(el.innerText);
            if (!text || text.length > 60 || text.includes('...')) return;

            if (isCyanish(style.color) || (style.fontWeight >= 700 && text.endsWith(':'))) {
                let val = '';
                let next = el.nextElementSibling || el.nextSibling;
                while (next && next.nodeType === 3 && !next.textContent.trim()) next = next.nextSibling;

                if (next) {
                    if (next.tagName === 'SELECT') val = next.options[next.selectedIndex]?.text || '';
                    else if (next.tagName === 'INPUT') val = next.value || '';
                    else if (next.nodeType === 1 || next.nodeType === 3) {
                        const nStyle = next.nodeType === 1 ? window.getComputedStyle(next) : null;
                        if (!nStyle || !isCyanish(nStyle.color)) val = clean(next.textContent || next.innerText);
                    }
                }

                if (val && val !== text && val.length < 500) {
                    let wasShifted = false;
                    for (const pk of CONFIG.LABELS) {
                        if (val.toUpperCase().startsWith(pk) && text.toUpperCase() !== pk) {
                            addDetail(pk, val.substring(pk.length).trim());
                            wasShifted = true;
                        }
                    }
                    if (!wasShifted) addDetail(text, val);
                }
            }
        });

        // PHASE D: Structural Metadata (Dropdowns & Hidden)
        const teamEl = document.querySelector(CONFIG.SELECTORS.TEAM_DROPDOWN);
        if (teamEl && !teamEl.value.includes('-- Select Team --')) {
            data.teamDetails['SELECTED TEAM'] = teamEl.options[teamEl.selectedIndex]?.text || '';
        }

        CONFIG.SELECTORS.HIDDEN_INPUTS.forEach(id => {
            const el = document.getElementById(id);
            if (el) data.hiddenInfo[id.toUpperCase()] = el.value || '';
        });

        const userEl = document.querySelector(CONFIG.SELECTORS.USER_PROFILE);
        if (userEl) data.currentUser = clean(userEl.innerText).replace('Welcome, ', '');

        // --- Persistence Logic ---
        // Only update current tab in allTabs if we found substantial data
        if (Object.keys(data.details).length > 2 || data.materialDetails.length > 0) {
            sodCache.tabs[data.activeTab] = JSON.parse(JSON.stringify(data.details));
            data.allTabs = sodCache.tabs; // Sync data object with updated cache
            await new Promise(r => chrome.storage.local.set({ [`sod_${soNum}`]: sodCache.tabs }, r));
        }

        chrome.storage.local.set({ lastScraped: data });

        // --- Push Logic ---
        if (data.soNum && data.activeTab !== 'IMAGES' && data.activeTab !== 'PHOTOS') {
            const hash = JSON.stringify({ so: data.soNum, tabs: data.allTabs, materials: data.materialDetails });
            if (hash !== lastPushedHash) {
                chrome.runtime.sendMessage({ action: 'pushToERP', data }, (res) => {
                    const err = chrome.runtime.lastError;
                    if (!err && res?.success) {
                        lastPushedHash = hash;
                        updateIndicator('SYNC OK', '#22c55e');
                    } else {
                        updateIndicator('BRIDGE ERROR', '#ef4444');
                    }
                });
            }
        }
    } catch (e) {
        console.error('[SLT-BRIDGE] Scrape Error:', e);
    } finally {
        isScraping = false;
    }
}

// --- 4. ENGINE SETUP ---

const observer = new MutationObserver(() => {
    // Throttled scrape on mutation
    if (!isScraping) scrape();
});
observer.observe(document.body, { childList: true, subtree: true });

if (!document.getElementById('slt-erp-indicator')) {
    const b = document.createElement('div');
    b.id = 'slt-erp-indicator';
    b.style.cssText = `position: fixed; top: 10px; right: 20px; z-index: 2147483647; background: #0f172a; color: #fff; padding: 6px 14px; font-size: 11px; font-weight: 600; border-radius: 8px; display: flex; align-items: center; gap: 8px; pointer-events: none;`;
    b.innerHTML = `<div style="width: 8px; height: 8px; border-radius: 50%; background: #22c55e;" id="slt-erp-status-dot"></div><span id="slt-erp-status-tag">SLT BRIDGE v${CURRENT_VERSION}</span>`;
    document.body.appendChild(b);
}

function updateIndicator(status, color) {
    const tag = document.getElementById('slt-erp-status-tag');
    const dot = document.getElementById('slt-erp-status-dot');
    if (tag && dot) {
        tag.textContent = status;
        dot.style.background = color;
        dot.style.boxShadow = `0 0 8px ${color}`;
    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getPortalData") {
        scrape().then(res => sendResponse(res));
    }
    return true;
});

setInterval(scrape, 3500); // Slower interval to avoid race conditions
scrape();
