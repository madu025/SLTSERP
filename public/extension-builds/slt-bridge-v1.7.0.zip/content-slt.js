// SLT-ERP Bridge Extension v1.7.0 (The Ultra-Advanced Omniscient Scraper)
// Goals: Color-Agnostic, Visual Assets, Grid-Search, Deep Persistence
console.log('🚀 [SLT-BRIDGE] Ultra-Scraper v1.7.0 starting...');

const CURRENT_VERSION = '1.7.0';

// --- 1. MAPPING CONFIGURATION ---
const CONFIG = {
    SELECTORS: {
        USER_PROFILE: '.user-profile-dropdown h6',
        ACTIVE_TAB: '.nav-tabs .nav-link.active',
        TEAM_DROPDOWN: '#mobusr',
        HIDDEN_INPUTS: ['iptv1', 'iptv2', 'iptv3', 'bb', 'voice2', 'sval']
    },
    TABLE_HEADERS: {
        ATTRIBUTE: ['ATTRIBUTE NAME', 'ITEM', 'COMPONENT', 'PARAMETER', 'DESCRIPTION'],
        VALUE: ['DEFAULT VALUE', 'VALUE', 'QTY', 'QUANTITY', 'SERIAL NUMBER', 'RESULT']
    },
    JUNK_KEYS: [
        'WELCOME', 'LOGOUT', 'WARNING', 'CONNECTION DETAIL', 'LATEST', 'HOME',
        'DASHBOARD', 'SEARCH', 'REFRESH', 'PROFILE', 'SETTINGS', 'PENDING IMAGES',
        'COPYRIGHT', 'ALL RIGHTS RESERVED', 'NOTIFICATIONS'
    ],
    // Known key concepts to prioritize if found inside values
    PRIORITY_LABELS: [
        'RECEIVED DATE', 'RTOM', 'TASK', 'STATUS', 'ADDRESS', 'CUSTOMER NAME',
        'ORDER TYPE', 'SERVICE TYPE', 'PACKAGE', 'SERVICE ORDER', 'SOD',
        'STATUS DATE', 'EQUIPMENT CLASS', 'CONTACT NO', 'CIRCUIT', 'LINE TYPE',
        'TEST TYPE', 'MOBILE TEAM', 'DEFAULT VALUE', 'ONT_ROUTER_SERIAL_NUMBER',
        'OLT MANUFACTURER', 'DESCRIPTION'
    ]
};

let lastPushedHash = "";
let sodCache = { soNum: '', tabs: {} };
let isScraping = false;

// --- 2. UTILITY FUNCTIONS ---

const clean = (txt) => txt ? txt.replace(/\s+/g, ' ').trim() : '';

function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    // Be inclusive: only block if explicitly hidden
    return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
}

// --- 3. CORE SCRAPING ENGINE ---

async function scrape() {
    if (isScraping || !chrome.runtime?.id) return;
    isScraping = true;

    try {
        const url = window.location.href;
        const sodMatch = url.match(/[?&]sod=([A-Z0-9]+)/i);
        const soNum = (sodMatch ? sodMatch[1].toUpperCase() : '').trim();

        if (!soNum) {
            isScraping = false;
            return null;
        }

        // 1. Sync Cache with Storage
        if (soNum !== sodCache.soNum) {
            const result = await new Promise(r => chrome.storage.local.get([`sod_${soNum}`], r));
            sodCache.soNum = soNum;
            sodCache.tabs = result[`sod_${soNum}`] || {};
        }

        const activeTabEl = document.querySelector(CONFIG.SELECTORS.ACTIVE_TAB);
        const activeTab = activeTabEl ? clean(activeTabEl.innerText).toUpperCase() : 'GENERAL';

        const data = {
            url: url,
            soNum: soNum,
            activeTab: activeTab,
            timestamp: new Date().toISOString(),
            details: {},
            allTabs: sodCache.tabs,
            teamDetails: {},
            materialDetails: [],
            visualDetails: [], // NEW: Image/Photo URLs
            hiddenInfo: {},
            currentUser: ''
        };

        const addDetail = (key, val) => {
            if (!key || !val || val === '0' || val.toUpperCase().includes('SELECT MATERIAL')) return;
            key = key.replace(':', '').replace(',', '').trim().toUpperCase();

            // Advanced Junk Filter
            const valUpper = val.toUpperCase();
            if (CONFIG.JUNK_KEYS.some(jk => key.includes(jk) || valUpper.includes(jk))) return;
            if (key.length < 2 || /^[0-9]+$/.test(key)) return;

            if (data.details[key]) {
                if (data.details[key] === val) return;
                if (Array.isArray(data.details[key])) {
                    if (!data.details[key].includes(val)) data.details[key].push(val);
                } else {
                    data.details[key] = [data.details[key], val];
                }
            } else {
                data.details[key] = val;
            }
        };

        // --- PHASE A: Visual Asset Extraction ---
        if (activeTab.includes('IMAGE') || activeTab.includes('PHOTO') || activeTab.includes('ATTACHMENT')) {
            document.querySelectorAll('img').forEach(img => {
                if (!isVisible(img)) return;
                const src = img.src || img.dataset.src;
                if (src && !src.includes('data:image') && src.length > 5) {
                    data.visualDetails.push({
                        url: src,
                        alt: img.alt || 'Portal Image',
                        tab: activeTab
                    });
                }
            });
        }

        // --- PHASE B: Universal Structural Pair Discovery (Color-Agnostic) ---
        // Search for anything that looks like a Label
        document.querySelectorAll('label, b, strong, th, span, dt, .label-class').forEach(el => {
            if (!isVisible(el)) return;
            const text = clean(el.innerText);
            if (!text || text.length > 60 || /^[0-9]+$/.test(text)) return;

            // Strategy 1: Label with 'for'
            if (el.tagName === 'LABEL' && el.htmlFor) {
                const target = document.getElementById(el.htmlFor);
                if (target && isVisible(target)) {
                    const val = target.tagName === 'SELECT' ? target.options[target.selectedIndex]?.text : target.value;
                    if (val) addDetail(text, val);
                }
            }

            // Strategy 2: Sibling Lookup (The primary Omni-Scraper tool)
            let val = '';
            let next = el.nextElementSibling || el.nextSibling;
            while (next && next.nodeType === 3 && !next.textContent.trim()) next = next.nextSibling;

            if (next) {
                if (['INPUT', 'SELECT', 'TEXTAREA'].includes(next.tagName)) {
                    val = next.tagName === 'SELECT' ? next.options[next.selectedIndex]?.text : next.value;
                } else if (next.nodeType === 1 || next.nodeType === 3) {
                    val = clean(next.textContent || next.innerText);
                }
            }

            // Strategy 3: Grid/Cell Lookup (Adjacent)
            if (!val || val === text) {
                const parent = el.closest('.row, tr, div');
                if (parent) {
                    const nextValEl = el.closest('td')?.nextElementSibling || el.closest('.col-sm-3')?.nextElementSibling;
                    if (nextValEl) val = clean(nextValEl.innerText);
                }
            }

            if (val && val !== text && val.length < 1000) {
                // Correct for shifted concepts
                let wasShifted = false;
                for (const pk of CONFIG.PRIORITY_LABELS) {
                    if (val.toUpperCase().startsWith(pk) && text.toUpperCase() !== pk) {
                        addDetail(pk, val.substring(pk.length).trim());
                        wasShifted = true;
                    }
                }
                if (!wasShifted) addDetail(text, val);
            }
        });

        // --- PHASE C: Reverse-Lookup Table Indexing ---
        document.querySelectorAll('table').forEach(table => {
            if (!isVisible(table)) return;
            const rows = Array.from(table.querySelectorAll('tr'));
            if (rows.length === 0) return;

            const headers = Array.from(rows[0].querySelectorAll('th, td')).map(c => clean(c.innerText).toUpperCase());
            const attrIdx = headers.findIndex(h => CONFIG.TABLE_HEADERS.ATTRIBUTE.some(k => h.includes(k)));
            const valIdx = headers.findIndex(h => CONFIG.TABLE_HEADERS.VALUE.some(k => h.includes(k)));

            rows.forEach((row, rIdx) => {
                const cells = Array.from(row.querySelectorAll('td, th'));
                if (cells.length < 2) return;

                if (attrIdx !== -1 && valIdx !== -1 && rIdx > 0) {
                    const k = clean(cells[attrIdx].innerText);
                    const v = clean(cells[valIdx].innerText);
                    if (k && v && !headers.includes(k.toUpperCase())) addDetail(k, v);
                } else if (cells.length === 2 && rIdx > 0) {
                    const k = clean(cells[0].innerText);
                    const v = clean(cells[1].innerText);
                    if (k && v && v !== k && !headers.includes(k.toUpperCase())) addDetail(k, v);
                }
            });

            // Materials Capture
            if (headers.some(h => h.includes('ITEM')) && (headers.some(h => h.includes('QTY')) || headers.some(h => h.includes('SERIAL')))) {
                const itemIdx = headers.findIndex(h => h.includes('ITEM'));
                const qtyIdx = headers.findIndex(h => h.includes('QTY') || h.includes('QUANTITY') || h.includes('SERIAL'));
                rows.forEach((row, rIdx) => {
                    if (rIdx === 0) return;
                    const tds = row.querySelectorAll('td');
                    if (tds.length > Math.max(itemIdx, qtyIdx)) {
                        const item = clean(tds[itemIdx].innerText);
                        const qty = clean(tds[qtyIdx].innerText);
                        if (item && qty && !item.toUpperCase().includes('ITEM')) {
                            data.materialDetails.push({ ITEM: 'MATERIAL', TYPE: item, QTY: qty });
                        }
                    }
                });
            }
        });

        // --- PHASE D: Metadata & Hidden Technical Codes ---
        const teamEl = document.querySelector(CONFIG.SELECTORS.TEAM_DROPDOWN);
        if (teamEl) {
            const selectedStr = teamEl.options[teamEl.selectedIndex]?.text || '';
            if (selectedStr && !selectedStr.includes('-- Select')) {
                data.teamDetails['SELECTED TEAM'] = selectedStr;
            }
        }

        CONFIG.SELECTORS.HIDDEN_INPUTS.forEach(id => {
            const el = document.getElementById(id);
            if (el) data.hiddenInfo[id.toUpperCase()] = el.value || '';
        });

        const userEl = document.querySelector(CONFIG.SELECTORS.USER_PROFILE);
        if (userEl) data.currentUser = clean(userEl.innerText).replace('Welcome, ', '');

        // --- Persistence Logic: Deep Smart Merge ---
        if (Object.keys(data.details).length > 0 || data.materialDetails.length > 0 || data.visualDetails.length > 0) {
            // Merge logic: Never delete, only add/update
            const currentTabContent = JSON.parse(JSON.stringify(data.details));
            sodCache.tabs[data.activeTab] = currentTabContent;

            // If we have visual data, merge into a global gallery
            if (data.visualDetails.length > 0) {
                if (!sodCache.tabs['VISUAL_GALLERY']) sodCache.tabs['VISUAL_GALLERY'] = [];
                data.visualDetails.forEach(v => {
                    if (!sodCache.tabs['VISUAL_GALLERY'].find(exist => exist.url === v.url)) {
                        sodCache.tabs['VISUAL_GALLERY'].push(v);
                    }
                });
            }

            data.allTabs = sodCache.tabs;
            await new Promise(r => chrome.storage.local.set({ [`sod_${soNum}`]: sodCache.tabs }, r));
        }

        chrome.storage.local.set({ lastScraped: data });

        // --- Push Logic ---
        if (data.soNum) {
            const hash = JSON.stringify({ so: data.soNum, tabs: data.allTabs, materials: data.materialDetails });
            if (hash !== lastPushedHash) {
                chrome.runtime.sendMessage({ action: 'pushToERP', data }, (res) => {
                    if (!chrome.runtime.lastError && res?.success) {
                        lastPushedHash = hash;
                        updateIndicator('SYNC OK', '#22c55e');
                    } else {
                        updateIndicator('BRIDGE ERROR', '#ef4444');
                    }
                });
            }
        }
    } catch (e) {
        console.error('[SLT-BRIDGE] Scrape Error:', e);
    } finally {
        isScraping = false;
    }
}

// --- 4. ENGINE SETUP (Mutation Reactive) ---

const observer = new MutationObserver(() => {
    if (!isScraping) scrape();
});
observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style'] });

if (!document.getElementById('slt-erp-indicator')) {
    const b = document.createElement('div');
    b.id = 'slt-erp-indicator';
    b.style.cssText = `position: fixed; top: 10px; right: 20px; z-index: 2147483647; background: #0f172a; color: #fff; padding: 6px 14px; font-size: 11px; font-weight: 600; border-radius: 8px; display: flex; align-items: center; gap: 8px; pointer-events: none;`;
    b.innerHTML = `<div style="width: 8px; height: 8px; border-radius: 50%; background: #22c55e;" id="slt-erp-status-dot"></div><span id="slt-erp-status-tag">SLT BRIDGE v${CURRENT_VERSION}</span>`;
    document.body.appendChild(b);
}

function updateIndicator(status, color) {
    const tag = document.getElementById('slt-erp-status-tag');
    const dot = document.getElementById('slt-erp-status-dot');
    if (tag && dot) {
        tag.textContent = status;
        dot.style.background = color;
        dot.style.boxShadow = `0 0 8px ${color}`;
    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getPortalData") {
        scrape().then(res => sendResponse(res));
    }
    return true;
});

setInterval(scrape, 4000);
scrape();
function updateIndicator(status, color) {
    const tag = document.getElementById('slt-erp-status-tag');
    const dot = document.getElementById('slt-erp-status-dot');
    if (tag && dot) {
        tag.textContent = status;
        dot.style.background = color;
        dot.style.boxShadow = `0 0 8px ${color}`;
    }
}
