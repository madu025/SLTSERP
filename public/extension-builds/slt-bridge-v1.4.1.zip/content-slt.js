// Comprehensive Scraper for SLT i-Shamp Portal v1.4.1
console.log('🚀 [SLT-BRIDGE] Content script injected and starting...');
const CURRENT_VERSION = '1.4.1';

let lastPushedHash = "";

function updateLocalDiagnostics(foundItems, context) {
    if (!chrome.runtime?.id) return;
    chrome.storage.local.set({
        diagnostics_slt: {
            status: 'ACTIVE',
            lastScrapeTime: new Date().toLocaleTimeString(),
            elementsFound: foundItems,
            context: context,
            url: window.location.href
        }
    });
}

function updateIndicator(status, color) {
    const tag = document.getElementById('slt-erp-status-tag');
    const dot = document.getElementById('slt-erp-status-dot');
    if (tag && dot) {
        tag.textContent = status;
        dot.style.background = color;
        dot.style.boxShadow = `0 0 8px ${color}`;
        if (status === 'SYNC OK') {
            setTimeout(() => { if (tag.textContent === 'SYNC OK') tag.textContent = 'SLT BRIDGE v' + CURRENT_VERSION; }, 3000);
        }
    }
}

let sodCache = {
    soNum: '',
    tabs: {}
};

function isVisible(el) {
    return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
}

async function scrape() {
    if (!chrome.runtime?.id) return;

    const url = window.location.href;
    const sodMatch = url.match(/[?&]sod=([A-Z0-9]+)/i);
    const soNum = (sodMatch ? sodMatch[1].toUpperCase() : '').trim();

    // 1. Accumulation Management
    if (soNum && soNum !== sodCache.soNum) {
        sodCache.soNum = soNum;
        const result = await new Promise(r => chrome.storage.local.get([`sod_${soNum}`], r));
        sodCache.tabs = result[`sod_${soNum}`] || {};
    }

    const activeTabEl = document.querySelector('.nav-tabs .nav-link.active');
    const activeTab = activeTabEl ? activeTabEl.innerText.replace(/\s+/g, ' ').trim() : 'ORDER DETAILS';

    const data = {
        url: window.location.href,
        soNum: soNum,
        activeTab: activeTab,
        timestamp: new Date().toISOString(),
        details: {}, // Current tab data
        allTabs: sodCache.tabs, // Cumulative data
        teamDetails: {},
        materialDetails: [],
        hiddenInfo: {},
        currentUser: ''
    };

    const clean = (txt) => txt ? txt.replace(/\s+/g, ' ').trim() : '';

    const addDetail = (key, val) => {
        if (!key || !val) return;
        if (data.details[key]) {
            if (data.details[key] === val) return;
            if (Array.isArray(data.details[key])) {
                if (!data.details[key].includes(val)) data.details[key].push(val);
            } else {
                data.details[key] = [data.details[key], val];
            }
        } else {
            data.details[key] = val;
        }
    };

    const isCyanish = (color) => {
        if (!color) return false;
        if (color === 'rgb(13, 202, 240)' || color === 'rgb(0, 202, 240)' || color.includes('0dcaf0')) return true;
        const m = color.match(/\d+/g);
        if (m && m.length >= 3) {
            const r = parseInt(m[0]), g = parseInt(m[1]), b = parseInt(m[2]);
            return g > 150 && b > 150 && r < 100;
        }
        return false;
    };

    // 1. User
    const userEl = document.querySelector('.user-profile-dropdown h6');
    if (userEl) data.currentUser = clean(userEl.innerText).replace('Welcome, ', '');

    // 2. Hidden
    ['iptv1', 'iptv2', 'iptv3', 'bb', 'voice2', 'sval'].forEach(id => {
        const el = document.getElementById(id);
        if (el) data.hiddenInfo[id.toUpperCase()] = el.value || '';
    });

    // 3. TABLE / LIST SCRAPER (AGGRESSIVE FOR SERIAL NUMBERS AND GRIDS)
    document.querySelectorAll('table').forEach(table => {
        if (!isVisible(table)) return;

        const trs = Array.from(table.querySelectorAll('tr'));
        let attrColIdx = -1;
        let valColIdx = -1;

        trs.forEach((tr) => {
            const cells = Array.from(tr.querySelectorAll('td, th'));
            cells.forEach((cell, cIdx) => {
                const txt = clean(cell.innerText).toUpperCase();
                if (txt.includes('ATTRIBUTE NAME')) attrColIdx = cIdx;
                if (txt.includes('DEFAULT VALUE') || (txt.includes('VALUE') && attrColIdx !== -1)) valColIdx = cIdx;
            });

            if (attrColIdx !== -1 && valColIdx !== -1) {
                const rowCells = Array.from(tr.querySelectorAll('td'));
                if (rowCells.length > Math.max(attrColIdx, valColIdx)) {
                    const k = clean(rowCells[attrColIdx].innerText).toUpperCase();
                    const v = clean(rowCells[valColIdx].innerText);
                    if (k && v && !k.includes('ATTRIBUTE NAME')) {
                        addDetail(k, v);
                    }
                }
            }
        });
    });

    // 4. UNIVERSAL SCRAPER (Labels with robustness)
    const POSS_KEYS = ['RECEIVED DATE', 'RTOM', 'TASK', 'STATUS', 'ADDRESS', 'CUSTOMER NAME', 'ORDER TYPE', 'SERVICE TYPE', 'PACKAGE', 'SERVICE ORDER', 'SOD', 'STATUS DATE', 'EQUIPMENT CLASS', 'CONTACT NO', 'CIRCUIT', 'LINE TYPE', 'TEST TYPE', 'MOBILE TEAM', 'DEFAULT VALUE', 'ONT_ROUTER_SERIAL_NUMBER', 'OLT MANUFACTURER', 'DESCRIPTION'];

    document.querySelectorAll('label, b, strong, span, th, td, div').forEach(el => {
        if (!isVisible(el)) return;
        if (el.children.length > 3 && !['TD', 'TH'].includes(el.tagName)) return;

        const style = window.getComputedStyle(el);
        if (isCyanish(style.color)) {
            const key = clean(el.innerText).toUpperCase();
            if (!key || key.length > 50 || key === 'LATEST' || /^[0-9]+$/.test(key)) return;

            let val = '';
            // Strategy: Sibling
            let next = el.nextElementSibling || el.nextSibling;
            while (next && next.nodeType === 3 && !next.textContent.trim()) next = next.nextSibling;

            if (next) {
                if (next.tagName === 'SELECT') {
                    val = next.options[next.selectedIndex]?.text || '';
                } else {
                    const nextStyle = next.nodeType === 1 ? window.getComputedStyle(next) : null;
                    if (!nextStyle || !isCyanish(nextStyle.color)) {
                        val = clean(next.textContent || next.innerText);
                    }
                }
            }

            // Grid Fallback
            if (!val || val.toUpperCase() === key) {
                const col = el.closest('[class*="col-"]');
                const row = col?.parentElement;
                if (row && col && row.classList.contains('row')) {
                    const idx = Array.from(row.children).indexOf(col);
                    let nextR = row.nextElementSibling;
                    while (nextR && nextR.tagName !== 'DIV') nextR = nextR.nextElementSibling;
                    if (nextR && nextR.classList.contains('row')) {
                        const target = nextR.children[idx];
                        if (target) {
                            const sel = target.querySelector('select');
                            if (sel) {
                                val = sel.options[sel.selectedIndex]?.text || '';
                            } else {
                                const tStyle = window.getComputedStyle(target);
                                if (!isCyanish(tStyle.color)) val = clean(target.innerText);
                            }
                        }
                    }
                }
            }

            if (val && val !== key && val.length < 500 && !val.includes('SELECT MATERIAL')) {
                let wasShifted = false;
                for (const pk of POSS_KEYS) {
                    if (val.startsWith(pk) && key !== pk) {
                        addDetail(pk, val.replace(pk, '').trim());
                        wasShifted = true;
                    }
                }
                if (!wasShifted) {
                    addDetail(key, val);
                }
            }
        }
    });

    // 5. Team & Added Materials
    const teamEl = document.getElementById('mobusr');
    if (teamEl && !teamEl.value.includes('-- Select Team --')) {
        data.teamDetails['SELECTED TEAM'] = teamEl.options[teamEl.selectedIndex]?.text || '';
    }

    // Material Table Scraper
    document.querySelectorAll('table').forEach(table => {
        if (!isVisible(table)) return;
        const text = clean(table.innerText).toUpperCase();
        if (text.includes('ITEM') || text.includes('QTY')) {
            table.querySelectorAll('tr').forEach(row => {
                const td = row.querySelectorAll('td');
                if (td.length >= 2) {
                    const item = clean(td[0].innerText);
                    const qty = clean(td[1].innerText);
                    if (qty && item && !item.includes('ITEM') && !item.includes('SELECT')) {
                        if (item.includes('-') || item.includes('POLE') || /^[A-Z0-9-]+$/.test(item.split(' ')[0])) {
                            data.materialDetails.push({ ITEM: 'MATERIAL', TYPE: item, QTY: qty });
                        }
                    }
                }
            });
        }
    });

    // 6. Update Cumulative Cache
    if (data.soNum) {
        const currentDetails = JSON.parse(JSON.stringify(data.details));
        sodCache.tabs[data.activeTab] = currentDetails;
        chrome.storage.local.set({ [`sod_${data.soNum}`]: sodCache.tabs });
    }

    chrome.storage.local.set({ lastScraped: data });
    updateLocalDiagnostics(Object.keys(data.details).length, data.activeTab);

    if (data.soNum) {
        if (data.activeTab === 'IMAGES' || data.activeTab === 'PHOTOS') { updateIndicator('ACTIVE (SKIP TAB)', '#94a3b8'); return data; }

        const hash = JSON.stringify({ so: data.soNum, tabs: data.allTabs, materials: data.materialDetails });
        if (hash !== lastPushedHash) {
            chrome.runtime.sendMessage({ action: 'pushToERP', data }, (res) => {
                if (!chrome.runtime.lastError && res?.success) { lastPushedHash = hash; updateIndicator('SYNC OK', '#22c55e'); }
                else { updateIndicator('BRIDGE ERROR', '#ef4444'); }
            });
        }
    }
    return data;
}

if (!document.getElementById('slt-erp-indicator')) {
    const b = document.createElement('div');
    b.id = 'slt-erp-indicator';
    b.style.cssText = `position: fixed; top: 10px; right: 20px; z-index: 2147483647; background: #0f172a; color: #fff; padding: 6px 14px; font-size: 11px; font-weight: 600; border-radius: 8px; display: flex; align-items: center; gap: 8px; pointer-events: none;`;
    b.innerHTML = `<div style="width: 8px; height: 8px; border-radius: 50%; background: #22c55e;" id="slt-erp-status-dot"></div><span id="slt-erp-status-tag">SLT BRIDGE v${CURRENT_VERSION}</span>`;
    document.body.appendChild(b);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getPortalData") {
        scrape().then(res => sendResponse(res));
    }
    return true;
});

setInterval(scrape, 2000);
scrape();
