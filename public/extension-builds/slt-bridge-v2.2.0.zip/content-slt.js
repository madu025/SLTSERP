/**
 * SLT-ERP Bridge v2.2.0 "NEXUS-CORE"
 * Engine: Spatial-Awareness Data Harvesting
 * Feature: Coordinate Grouping & Integrity Filtering
 */

console.log('%c⚡ [SLT-NEXUS-CORE] v2.2.0 Online', 'color: #f59e0b; font-weight: bold; font-size: 14px;');

const VERSION = '2.2.0';

const CONFIG = {
    CYAN: 'rgb(0, 202, 240)',
    JUNK: [/WELCOME/i, /LOGOUT/i, /WARNING/i, /DASHBOARD/i, /17695/i, /17694/i], // Integrity Guard
    PRIORITY: ['RTOM', 'SERVICE ORDER', 'CIRCUIT', 'SERVICE', 'RECEIVED DATE', 'CUSTOMER NAME', 'CONTACT NO', 'ADDRESS', 'STATUS', 'PACKAGE', 'TEAM', 'SERIAL', 'ONT', 'IPTV', 'MATERIAL']
};

let CACHE = { so: '', tabs: {}, lastHash: '' };

const NexusUtils = {
    clean: (t) => t ? t.replace(/\s+/g, ' ').trim() : '',

    isJunk: (t) => {
        if (!t) return true;
        return CONFIG.JUNK.some(p => p.test(t)) || (t.length > 5 && !isNaN(t) && t.startsWith('1769'));
    },

    isLabel: (el) => {
        const style = window.getComputedStyle(el);
        const color = style.color;
        const isCyan = color === CONFIG.CYAN || color === 'rgb(13, 202, 240)' || color.includes('0dcaf0');
        const isBold = parseInt(style.fontWeight) >= 700;
        const text = NexusUtils.clean(el.innerText || '');
        return (isCyan || (isBold && text.endsWith(':'))) && text.length < 50;
    }
};

class NexusHarvester {
    static harvest() {
        const data = { details: {}, materials: [], visuals: [] };
        const activeTab = this.getTab();

        // 1. SPATIAL SCAN (Grid & Containers)
        // Find all Cyan-Labels first as Anchors
        document.querySelectorAll('label, b, strong, th, span, div, td').forEach(el => {
            if (NexusUtils.isLabel(el)) {
                let k = NexusUtils.clean(el.innerText).replace(':', '').toUpperCase();
                if (NexusUtils.isJunk(k)) return;

                let v = '';

                // Strategy: Find nearest value in the same parent container or neighbor
                const container = el.closest('td, .col-md-3, .col-sm-3, .form-group, .row');
                if (container) {
                    // Get all text in container, remove label part
                    const fullText = NexusUtils.clean(container.innerText);
                    v = fullText.replace(el.innerText, '').trim();

                    // If empty, check for inputs/selects inside container
                    const input = container.querySelector('input, select');
                    if (input) v = input.tagName === 'SELECT' ? input.options[input.selectedIndex]?.text : input.value;
                }

                // Fallback to strict sibling if container scan failed
                if (!v || v === k) {
                    let next = el.nextElementSibling || el.nextSibling;
                    while (next && next.nodeType === 3 && !next.textContent.trim()) next = next.nextSibling;
                    if (next) {
                        v = (next.tagName === 'INPUT' || next.tagName === 'SELECT') ?
                            (next.tagName === 'SELECT' ? next.options[next.selectedIndex]?.text : next.value) :
                            NexusUtils.clean(next.innerText || next.textContent);
                    }
                }

                if (v && v !== k && !NexusUtils.isJunk(v)) {
                    data.details[k] = v;
                }
            }
        });

        // 2. TABLE MATRIX SCAN (For Serial Numbers & Materials)
        document.querySelectorAll('table').forEach(table => {
            const rows = Array.from(table.querySelectorAll('tr'));
            if (rows.length < 1) return;
            const headers = Array.from(rows[0].querySelectorAll('td, th')).map(c => NexusUtils.clean(c.innerText).toUpperCase());

            rows.forEach((r, idx) => {
                const cells = Array.from(r.querySelectorAll('td, th'));
                if (cells.length < 2) return;

                // Property-List style table (Left Header, Right Value)
                if (cells.length === 2 && !headers.includes(NexusUtils.clean(cells[0].innerText).toUpperCase())) {
                    const k = NexusUtils.clean(cells[0].innerText).toUpperCase();
                    const v = NexusUtils.clean(cells[1].innerText);
                    if (k && v && !NexusUtils.isJunk(k)) data.details[k] = v;
                }

                // Material Grid Style
                const itemIdx = headers.findIndex(h => h.includes('ITEM') || h.includes('DESCRIPTION'));
                const valIdx = headers.findIndex(h => h.includes('QTY') || h.includes('QUANTITY') || h.includes('SERIAL') || h.includes('VALUE'));

                if (itemIdx !== -1 && valIdx !== -1 && idx > 0) {
                    const item = NexusUtils.clean(cells[itemIdx].innerText);
                    const val = NexusUtils.clean(cells[valIdx].innerText);
                    if (item && val && !NexusUtils.isJunk(item)) {
                        if (headers[itemIdx].includes('ITEM')) data.materials.push({ ITEM: 'MATERIAL', TYPE: item, QTY: val });
                        else data.details[item.toUpperCase()] = val;
                    }
                }
            });
        });

        // 3. IMAGE DEEP HARVEST
        if (activeTab.includes('IMAGE') || activeTab.includes('PHOTO')) {
            document.querySelectorAll('img').forEach(img => {
                const src = img.src || img.dataset.src || img.dataset.original;
                if (src && src.startsWith('http') && src.length > 20 && !src.includes('no-image')) {
                    data.visuals.push({ url: src, alt: img.alt || 'Asset' });
                }
            });
        }

        return data;
    }

    static getTab() {
        const el = document.querySelector('.nav-tabs .nav-link.active') || document.querySelector('.active a') || { innerText: 'GENERAL' };
        return NexusUtils.clean(el.innerText).toUpperCase();
    }
}

async function startCore() {
    if (!chrome.runtime?.id) return;
    const url = window.location.href;
    const soMatch = url.match(/[?&]sod=([A-Z0-9]+)/i);
    const so = soMatch ? soMatch[1].toUpperCase() : '';
    if (!so) return;

    // Load from Persistence
    if (so !== CACHE.so) {
        const saved = await new Promise(r => chrome.storage.local.get([`sod_${so}`], r));
        CACHE.so = so;
        CACHE.tabs = saved[`sod_${so}`] || {};
    }

    const currentTab = NexusHarvester.getTab();
    const harvested = NexusHarvester.harvest();

    // Nexus Smart Merge (Additive Only)
    if (Object.keys(harvested.details).length > 0) {
        CACHE.tabs[currentTab] = { ...(CACHE.tabs[currentTab] || {}), ...harvested.details };

        // Gallery Sync
        if (harvested.visuals.length > 0) {
            if (!CACHE.tabs['GALLERY']) CACHE.tabs['GALLERY'] = [];
            harvested.visuals.forEach(v => {
                if (!CACHE.tabs['GALLERY'].find(x => x.url === v.url)) CACHE.tabs['GALLERY'].push(v);
            });
        }
    }

    const payload = {
        url: url,
        soNum: so,
        activeTab: currentTab,
        timestamp: new Date().toISOString(),
        details: harvested.details,
        allTabs: CACHE.tabs,
        teamDetails: { 'SELECTED TEAM': NexusUtils.clean(document.querySelector('#mobusr option:checked')?.text || "") },
        materialDetails: harvested.materials,
        visualDetails: harvested.visuals,
        currentUser: NexusUtils.clean(document.querySelector('.user-profile-dropdown h6')?.innerText || "").replace("Welcome, ", "")
    };

    const hash = btoa(JSON.stringify(payload.allTabs)).substring(0, 32);
    if (hash !== CACHE.lastHash) {
        CACHE.lastHash = hash;
        chrome.storage.local.set({ lastScraped: payload, [`sod_${so}`]: CACHE.tabs });
        chrome.runtime.sendMessage({ action: 'pushToERP', data: payload });
    }
}

// Coordinate Reaction
const nexusObserver = new MutationObserver(() => startCore());
nexusObserver.observe(document.body, { childList: true, subtree: true, attributes: true });

// UI Tag
if (!document.getElementById('nexus-tag')) {
    const b = document.createElement('div');
    b.id = 'nexus-tag';
    b.style.cssText = `position: fixed; bottom: 10px; left: 20px; z-index: 999999; background: #000; color: #f59e0b; padding: 5px 12px; border: 1px solid #f59e0b; border-radius: 4px; font-family: monospace; font-size: 10px; font-weight: bold; pointer-events: none;`;
    b.innerHTML = `NEXUS-CORE v${VERSION}`;
    document.body.appendChild(b);
}

startCore();
setInterval(startCore, 3000);
