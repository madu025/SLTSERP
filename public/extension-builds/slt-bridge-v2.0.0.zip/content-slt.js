/**
 * SLT-ERP Master Bridge Engine v2.0.0
 * Architecture: Intelligent State-Machine Harvesting
 * Author: Antigravity AI
 */

console.log('%c🚀 [SLT-MASTER-ENGINE] v2.0.0 Initializing...', 'color: #3b82f6; font-weight: bold; font-size: 14px;');

const VERSION = '2.0.0';

// --- 1. HARVESTING REGISTRY ---
const REGISTRY = {
    CONCEPTS: {
        SO_NUM: { selector: ['#sod', '[name="sod"]'], regex: /[?&]sod=([A-Z0-9]+)/i },
        TEAM: { selector: ['#mobusr', '#team_id'] },
        USER: { selector: ['.user-profile-dropdown h6', '#user_name'] },
        TABS: { selector: '.nav-tabs .nav-link' }
    },
    TABLE_SCHEMAS: {
        MATRICES: [
            { id: 'SERIAL_GRID', keys: ['ATTRIBUTE', 'COMPONENT'], values: ['VALUE', 'SERIAL', 'DEFAULT'] },
            { id: 'MATERIAL_GRID', keys: ['ITEM'], values: ['QTY', 'QUANTITY'] }
        ]
    },
    JUNK_PATTERNS: [/WELCOME/i, /LOGOUT/i, /WARNING/i, /DASHBOARD/i, /ALL RIGHTS RESERVED/i, /SELECT MATERIAL/i]
};

// --- 2. THE MASTER STATE ---
let MASTER_STATE = {
    soNum: '',
    currentTab: '',
    harvested: {}, // This is the Single Source of Truth for ALL tabs
    materials: [],
    visuals: [],
    lastHash: ''
};

// --- 3. ARCHITECTURAL UTILITIES ---
const Utils = {
    clean: (t) => t ? t.replace(/\s+/g, ' ').trim() : '',

    isJunk: (t) => REGISTRY.JUNK_PATTERNS.some(p => p.test(t)),

    isVisible: (el) => {
        const s = window.getComputedStyle(el);
        return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
    },

    getHash: (obj) => btoa(JSON.stringify(obj)).substring(0, 32),

    deepMerge: (target, source) => {
        for (const key in source) {
            if (source[key] instanceof Object && key in target) {
                Object.assign(source[key], Utils.deepMerge(target[key], source[key]));
            }
        }
        Object.assign(target || {}, source);
        return target;
    }
};

// --- 4. DISCOVERY LOGIC (Atomic) ---
class Harvester {
    static getActiveTab() {
        const el = document.querySelector(REGISTRY.CONCEPTS.TABS.selector + '.active');
        return el ? Utils.clean(el.innerText).toUpperCase() : 'GENERAL';
    }

    static getSoNum() {
        const match = window.location.href.match(REGISTRY.CONCEPTS.SO_NUM.regex);
        return match ? match[1].toUpperCase() : '';
    }

    static harvestTables() {
        const results = { details: {}, materials: [] };
        document.querySelectorAll('table').forEach(table => {
            if (!Utils.isVisible(table)) return;
            const rows = Array.from(table.querySelectorAll('tr'));
            if (rows.length < 1) return;

            const headers = Array.from(rows[0].querySelectorAll('td, th')).map(c => Utils.clean(c.innerText).toUpperCase());

            // Grid Discovery
            let schema = REGISTRY.TABLE_SCHEMAS.MATRICES.find(m =>
                headers.some(h => m.keys.some(k => h.includes(k))) &&
                headers.some(h => m.values.some(v => h.includes(v)))
            );

            if (schema) {
                const kIdx = headers.findIndex(h => schema.keys.some(k => h.includes(k)));
                const vIdx = headers.findIndex(h => schema.values.some(v => h.includes(v)));

                rows.forEach((r, i) => {
                    if (i === 0) return;
                    const cells = r.querySelectorAll('td');
                    if (cells.length > Math.max(kIdx, vIdx)) {
                        const k = Utils.clean(cells[kIdx].innerText);
                        const v = Utils.clean(cells[vIdx].innerText);
                        if (k && v && !Utils.isJunk(k)) {
                            if (schema.id === 'MATERIAL_GRID') results.materials.push({ ITEM: 'MATERIAL', TYPE: k, QTY: v });
                            else results.details[k.toUpperCase()] = v;
                        }
                    }
                });
            } else {
                // Fallback: Vertical Table (2 cells)
                rows.forEach(r => {
                    const cells = r.querySelectorAll('td');
                    if (cells.length === 2) {
                        const k = Utils.clean(cells[0].innerText).toUpperCase();
                        const v = Utils.clean(cells[1].innerText);
                        if (k && v && v !== k && !Utils.isJunk(k)) results.details[k] = v;
                    }
                });
            }
        });
        return results;
    }

    static harvestStructural() {
        const details = {};
        // Scan Bold/Label pairs across the entire DOM
        document.querySelectorAll('label, b, strong, th, span[style*="bold"], dt, .cyanish-label').forEach(el => {
            if (!Utils.isVisible(el)) return;
            let k = Utils.clean(el.innerText);
            if (!k || k.length > 50 || Utils.isJunk(k)) return;

            k = k.replace(':', '').toUpperCase();
            let v = '';

            // Sibling check (Input/Select/Text)
            let next = el.nextElementSibling || el.nextSibling;
            while (next && next.nodeType === 3 && !next.textContent.trim()) next = next.nextSibling;

            if (next) {
                if (['INPUT', 'SELECT', 'TEXTAREA'].includes(next.tagName)) {
                    v = next.tagName === 'SELECT' ? next.options[next.selectedIndex]?.text : next.value;
                } else {
                    v = Utils.clean(next.innerText || next.textContent);
                }
            }

            if (v && v !== k && v.length < 1000 && !Utils.isJunk(v)) {
                details[k] = v;
            }
        });
        return details;
    }

    static harvestImages() {
        const visuals = [];
        document.querySelectorAll('img').forEach(img => {
            if (!Utils.isVisible(img)) return;
            const src = img.src || img.dataset.src;
            if (src && src.startsWith('http') && src.length > 15) {
                visuals.push({ url: src, alt: img.alt || 'Asset' });
            }
        });
        return visuals;
    }
}

// --- 5. THE MAIN LOOP ---
async function runEngine() {
    if (!chrome.runtime?.id) return;

    const so = Harvester.getSoNum();
    if (!so) return;

    // Load Persistence from storage first if SO shifted
    if (so !== MASTER_STATE.soNum) {
        const saved = await new Promise(r => chrome.storage.local.get([`sod_${so}`], r));
        MASTER_STATE.soNum = so;
        MASTER_STATE.harvested = saved[`sod_${so}`] || {};
    }

    const tab = Harvester.getActiveTab();
    MASTER_STATE.currentTab = tab;

    // Execute Atomic Scraping
    const tableData = Harvester.harvestTables();
    const structData = Harvester.harvestStructural();
    const imageData = (tab.includes('IMAGE') || tab.includes('PHOTO')) ? Harvester.harvestImages() : [];

    // Intelligence Merge: Merge Current View into Master State
    const currentViewDetails = { ...structData, ...tableData.details };

    if (Object.keys(currentViewDetails).length > 0) {
        MASTER_STATE.harvested[tab] = currentViewDetails;

        // Sync visuals to a global gallery
        if (imageData.length > 0) {
            if (!MASTER_STATE.harvested['GALLERY']) MASTER_STATE.harvested['GALLERY'] = [];
            imageData.forEach(img => {
                if (!MASTER_STATE.harvested['GALLERY'].find(x => x.url === img.url)) {
                    MASTER_STATE.harvested['GALLERY'].push(img);
                }
            });
        }
    }

    // Capture specific components
    const teamEl = document.querySelector(REGISTRY.CONCEPTS.TEAM.selector[0]);
    const selectedTeam = teamEl?.options[teamEl.selectedIndex]?.text;
    const teamObj = (selectedTeam && !selectedTeam.includes('--')) ? { 'SELECTED TEAM': selectedTeam } : {};

    // Prepare Package for ERP
    const payload = {
        url: window.location.href,
        soNum: MASTER_STATE.soNum,
        activeTab: MASTER_STATE.currentTab,
        timestamp: new Date().toISOString(),
        details: currentViewDetails,
        allTabs: MASTER_STATE.harvested,
        teamDetails: teamObj,
        materialDetails: tableData.materials,
        visualDetails: imageData,
        currentUser: Utils.clean(document.querySelector(REGISTRY.CONCEPTS.USER.selector[0])?.innerText || "").replace("Welcome, ", "")
    };

    // Final Sync & Persistence
    const currentHash = Utils.getHash(payload.allTabs) + Utils.getHash(payload.materialDetails);

    if (currentHash !== MASTER_STATE.lastHash) {
        MASTER_STATE.lastHash = currentHash;

        // Save to Browser Storage
        chrome.storage.local.set({
            lastScraped: payload,
            [`sod_${so}`]: MASTER_STATE.harvested
        });

        // Push to ERP
        chrome.runtime.sendMessage({ action: 'pushToERP', data: payload }, (res) => {
            const err = chrome.runtime.lastError;
            if (!err && res?.success) UI.update('SYNC OK', '#22c55e');
            else UI.update('BRIDGE ERROR', '#ef4444');
        });
    }
}

// --- 6. UI OVERLAY ---
const UI = {
    init: () => {
        if (document.getElementById('slt-master-tag')) return;
        const b = document.createElement('div');
        b.id = 'slt-master-tag';
        b.style.cssText = `position: fixed; top: 12px; right: 20px; z-index: 999999; background: #1e293b; color: #fff; padding: 8px 16px; border-radius: 12px; font-family: sans-serif; font-size: 11px; font-weight: bold; border: 1px solid #334155; display: flex; align-items: center; gap: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.3); pointer-events: none;`;
        b.innerHTML = `<div style="width: 10px; height: 10px; border-radius: 50%; background: #22c55e;" id="slt-master-dot"></div><span>SLT MASTER v${VERSION}</span>`;
        document.body.appendChild(b);
    },
    update: (status, color) => {
        const dot = document.getElementById('slt-master-dot');
        const span = document.querySelector('#slt-master-tag span');
        if (dot && span) {
            dot.style.background = color;
            dot.style.boxShadow = `0 0 10px ${color}`;
            // Optional temporary text change
        }
    }
};

// --- 7. REACTION ENGINE ---
const Observer = new MutationObserver((mutations) => {
    // Only trigger if structural elements or inputs change
    const isSignificant = mutations.some(m => m.addedNodes.length > 0 || m.target.tagName === 'INPUT' || m.target.tagName === 'SELECT');
    if (isSignificant) runEngine();
});

// INITIALIZE
UI.init();
Observer.observe(document.body, { childList: true, subtree: true });
runEngine();
setInterval(runEngine, 5000); // Heartbeat sync
