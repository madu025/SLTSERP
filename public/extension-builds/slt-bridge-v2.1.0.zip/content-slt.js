/**
 * SLT-ERP Bridge v2.1.0 "Omni-Sensing Ghost"
 * High-Performance Data Harvesting Engine
 * Optimized for SLT i-Shamp Messy DOM
 */

console.log('%c👻 [SLT-GHOST-ENGINE] v2.1.0 Active', 'color: #00f2fe; font-weight: bold; font-size: 14px;');

const VERSION = '2.1.0';

const CONFIG = {
    CYAN: 'rgb(0, 202, 240)',
    JUNK: ['WELCOME', 'LOGOUT', 'WARNING', 'DASHBOARD', 'REFRESH', 'PROFILE', 'SETTINGS', 'PENDING IMAGES'],
    PRIORITY: ['RECEIVED DATE', 'RTOM', 'TASK', 'STATUS', 'ADDRESS', 'CUSTOMER NAME', 'ORDER TYPE', 'SERVICE TYPE', 'PACKAGE', 'SERVICE ORDER', 'SOD', 'MOBILE TEAM', 'DEFAULT VALUE', 'ONT_ROUTER_SERIAL_NUMBER', 'OLT MANUFACTURER', 'DESCRIPTION', 'CONTACT NO', 'CIRCUIT']
};

let MASTER_STATE = { soNum: '', harvested: {}, lastHash: '' };

const GhostUtils = {
    clean: (t) => t ? t.replace(/\s+/g, ' ').trim() : '',

    isJunk: (t) => {
        const u = t.toUpperCase();
        return CONFIG.JUNK.some(j => u.includes(j)) || u.includes('<SELECT') || u.includes('<INPUT');
    },

    isCyan: (el) => {
        const color = window.getComputedStyle(el).color;
        return color === CONFIG.CYAN || color === 'rgb(13, 202, 240)' || color.includes('0dcaf0');
    },

    getDeepValue: (el) => {
        if (!el) return '';
        if (el.tagName === 'SELECT') return el.options[el.selectedIndex]?.text || '';
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return el.value || '';

        // Find input inside
        const inner = el.querySelector('input, select');
        if (inner) return GhostUtils.getDeepValue(inner);

        return GhostUtils.clean(el.innerText || el.textContent);
    }
};

class GhostHarvester {
    static run() {
        const results = { details: {}, materials: [], visuals: [] };
        const activeTab = this.getTab();

        // 1. GHOST SCAN: Universal Pair Discovery
        // We look for Cyan elements OR Bold elements ending in :
        document.querySelectorAll('label, b, strong, th, span, td, div').forEach(el => {
            const style = window.getComputedStyle(el);
            const text = GhostUtils.clean(el.innerText);

            if (!text || text.length > 60 || GhostUtils.isJunk(text)) return;

            const isProbableLabel = GhostUtils.isCyan(el) || (style.fontWeight >= 700 && text.endsWith(':')) || (style.fontWeight >= 700 && el.tagName === 'TH');

            if (isProbableLabel) {
                let key = text.replace(':', '').toUpperCase();
                let val = '';

                // A. Direct value in the same cell/container but separated?
                // B. Next Sibling?
                let next = el.nextElementSibling || el.nextSibling;
                while (next && next.nodeType === 3 && !next.textContent.trim()) next = next.nextSibling;

                if (next) val = GhostUtils.getDeepValue(next);

                // C. Proximity Search: If no value, check the next TD or next structural block
                if (!val || val === text) {
                    const parentTd = el.closest('td');
                    if (parentTd?.nextElementSibling) val = GhostUtils.getDeepValue(parentTd.nextElementSibling);
                    else {
                        const parentRow = el.closest('.row');
                        const nextCol = el.closest('[class*="col-"]')?.nextElementSibling;
                        if (nextCol) val = GhostUtils.getDeepValue(nextCol);
                    }
                }

                if (val && val !== text && !GhostUtils.isJunk(val)) {
                    this.smartAdd(results.details, key, val);
                }
            }
        });

        // 2. MATRIX SCAN: Table Indexing
        document.querySelectorAll('table').forEach(table => {
            const rows = Array.from(table.querySelectorAll('tr'));
            if (rows.length < 1) return;
            const headers = Array.from(rows[0].querySelectorAll('td, th')).map(c => GhostUtils.clean(c.innerText).toUpperCase());

            const fieldMap = {
                attr: headers.findIndex(h => h.includes('ATTRIBUTE') || h.includes('ITEM') || h.includes('DESCRIPTION')),
                val: headers.findIndex(h => h.includes('VALUE') || h.includes('SERIAL') || h.includes('RESULT') || h.includes('QTY'))
            };

            if (fieldMap.attr !== -1 && fieldMap.val !== -1) {
                rows.forEach((r, i) => {
                    if (i === 0) return;
                    const cells = r.querySelectorAll('td');
                    if (cells.length > Math.max(fieldMap.attr, fieldMap.val)) {
                        const k = GhostUtils.clean(cells[fieldMap.attr].innerText);
                        const v = GhostUtils.clean(cells[fieldMap.val].innerText);
                        if (k && v && !GhostUtils.isJunk(k)) {
                            if (headers[fieldMap.attr].includes('ITEM')) results.materials.push({ ITEM: 'MATERIAL', TYPE: k, QTY: v });
                            else this.smartAdd(results.details, k.toUpperCase(), v);
                        }
                    }
                });
            }
        });

        // 3. IMAGE SCAN
        if (activeTab.includes('IMAGE') || activeTab.includes('PHOTO')) {
            document.querySelectorAll('img').forEach(img => {
                const src = img.src || img.dataset.src;
                if (src && src.startsWith('http')) results.visuals.push({ url: src, alt: img.alt });
            });
        }

        return results;
    }

    static smartAdd(details, key, val) {
        // Logic to split mashed data: e.g. "RTOM RECEIVED DATE 12/1..."
        let splitDone = false;
        for (const pk of CONFIG.PRIORITY) {
            if (val.toUpperCase().startsWith(pk) && key !== pk) {
                details[key] = val.substring(0, val.toUpperCase().indexOf(pk)).trim();
                details[pk] = val.substring(val.toUpperCase().indexOf(pk) + pk.length).trim();
                splitDone = true;
                break;
            }
        }
        if (!splitDone) {
            if (details[key]) {
                if (details[key] !== val) {
                    details[key] = Array.isArray(details[key]) ? [...details[key], val] : [details[key], val];
                }
            } else details[key] = val;
        }
    }

    static getTab() {
        const el = document.querySelector('.nav-tabs .nav-link.active') || document.querySelector('.active a');
        return el ? GhostUtils.clean(el.innerText).toUpperCase() : 'GENERAL';
    }
}

async function sync() {
    if (!chrome.runtime?.id) return;
    const url = window.location.href;
    const soMatch = url.match(/[?&]sod=([A-Z0-9]+)/i);
    const so = soMatch ? soMatch[1].toUpperCase() : '';
    if (!so) return;

    if (so !== MASTER_STATE.soNum) {
        const saved = await new Promise(r => chrome.storage.local.get([`sod_${so}`], r));
        MASTER_STATE.soNum = so;
        MASTER_STATE.harvested = saved[`sod_${so}`] || {};
    }

    const data = GhostHarvester.run();
    const currentTab = GhostHarvester.getTab();

    // Deep Save Strategy
    if (Object.keys(data.details).length > 0) {
        MASTER_STATE.harvested[currentTab] = { ...MASTER_STATE.harvested[currentTab], ...data.details };
    }

    const payload = {
        url: url,
        soNum: so,
        activeTab: currentTab,
        timestamp: new Date().toISOString(),
        details: data.details,
        allTabs: MASTER_STATE.harvested,
        teamDetails: { 'SELECTED TEAM': GhostUtils.getDeepValue(document.querySelector('#mobusr')) },
        materialDetails: data.materials,
        visualDetails: data.visuals,
        currentUser: GhostUtils.clean(document.querySelector('.user-profile-dropdown h6')?.innerText || "").replace("Welcome, ", "")
    };

    const hash = btoa(JSON.stringify(payload.allTabs)).substring(0, 32);
    if (hash !== MASTER_STATE.lastHash) {
        MASTER_STATE.lastHash = hash;
        chrome.storage.local.set({ lastScraped: payload, [`sod_${so}`]: MASTER_STATE.harvested });
        chrome.runtime.sendMessage({ action: 'pushToERP', data: payload });
    }
}

// Global Reaction
const ghostObserver = new MutationObserver(() => sync());
ghostObserver.observe(document.body, { childList: true, subtree: true, characterData: true });

// UI Tag
if (!document.getElementById('ghost-tag')) {
    const b = document.createElement('div');
    b.id = 'ghost-tag';
    b.style.cssText = `position: fixed; top: 10px; right: 20px; z-index: 999999; background: linear-gradient(135deg, #00f2fe 0%, #4facfe 100%); color: #fff; padding: 6px 14px; border-radius: 20px; font-family: 'Segoe UI', sans-serif; font-size: 11px; font-weight: bold; box-shadow: 0 4px 15px rgba(0,242,254,0.4); pointer-events: none;`;
    b.innerHTML = `GHOST ENGINE v${VERSION}`;
    document.body.appendChild(b);
}

sync();
setInterval(sync, 4000);
