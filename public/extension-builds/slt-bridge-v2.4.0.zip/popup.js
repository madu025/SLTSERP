/**
 * SLT-ERP Bridge v2.4.0 "ULTRON-FINAL"
 * Popup Logic: Reactive Data Sync & Diagnostics
 */

document.addEventListener('DOMContentLoaded', () => {
    // --- 1. TAB SWITCHING LOGIC ---
    const tabs = document.querySelectorAll('.tab');
    const views = {
        'tab-data': document.getElementById('view-data'),
        'tab-diag': document.getElementById('view-diag')
    };

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            Object.values(views).forEach(v => v.style.display = 'none');
            const targetId = tab.id.replace('tab', 'view');
            const targetView = document.getElementById(targetId);
            if (targetView) targetView.style.display = 'block';
        });
    });

    // --- 2. LIVE REFRESH CYCLE ---
    // This ensures colors and data update in real-time
    function refresh() {
        chrome.storage.local.get(['lastScraped'], (result) => {
            renderUI(result.lastScraped);
        });
    }

    // Refresh every 1.5 seconds for snappy feel
    setInterval(refresh, 1500);
    refresh();

    // Listen for storage changes to update instantly
    chrome.storage.onChanged.addListener((changes) => {
        if (changes.lastScraped) {
            renderUI(changes.lastScraped.newValue);
        }
    });
});

function renderUI(data) {
    const statusText = document.getElementById('status-text');
    const detailsList = document.getElementById('details-list');

    if (!data || !data.soNum) {
        renderEmptyState(statusText, detailsList);
        return;
    }

    // Update Status Header
    statusText.style.color = "#10b981";
    statusText.innerHTML = `● Live Capture Active<br><span style="font-size:10px; opacity:0.8;">SO: ${data.soNum} (${data.activeTab})</span>`;

    // Render Details
    detailsList.innerHTML = '';

    // 1. Service Order - Always TOP
    if (data.soNum) {
        detailsList.appendChild(createItem('ACTIVE ORDER', data.soNum, '#3b82f6', true));
    }

    // 2. Team Info
    if (data.teamDetails && data.teamDetails['SELECTED TEAM']) {
        detailsList.appendChild(createItem('ASSIGNED TEAM', data.teamDetails['SELECTED TEAM'], '#0ea5e9'));
    }

    // 3. Main Captured Details
    const details = data.details || {};
    Object.entries(details).forEach(([key, value]) => {
        if (key === 'SERVICE ORDER' && value === data.soNum) return;

        // Smart Color Coding
        let borderColor = '#3b82f6';
        if (['RTOM', 'EXCHANGE', 'REGION'].includes(key)) borderColor = '#10b981';
        if (['STATUS', 'STATUS DATE'].includes(key)) borderColor = '#8b5cf6';
        if (key.includes('SERIAL') || key.includes('ONT') || key.includes('IPTV')) borderColor = '#f43f5e';

        detailsList.appendChild(createItem(key, value, borderColor));
    });

    // 4. Material Summary
    if (data.materialDetails && data.materialDetails.length > 0) {
        const matCount = data.materialDetails.length;
        detailsList.appendChild(createItem('MATERIALS', `${matCount} Items Captured`, '#f59e0b', true));

        data.materialDetails.forEach(m => {
            const val = m.VALUE || m.QTY || 'N/A';
            detailsList.appendChild(createItem(`MAT: ${m.TYPE}`, `Qty: ${val}`, '#fbbf24'));
        });
    }

    updateDiagnostics(data);
}

function createItem(label, value, color, isBold = false) {
    const div = document.createElement('div');
    div.className = 'detail-item';
    div.style.borderLeft = `4px solid ${color}`;
    div.innerHTML = `
        <div class="label" style="color:${color}">${label}</div>
        <div class="value" style="${isBold ? 'font-weight:bold; font-size:13px; color:#1e293b' : ''}">${value}</div>
    `;
    return div;
}

function updateDiagnostics(data) {
    // Last Sync Timer
    const lastSync = new Date(data.timestamp);
    const now = new Date();
    const diff = Math.floor((now - lastSync) / 1000);
    const timeString = diff < 5 ? 'Just now' : `${diff}s ago`;

    const syncEl = document.getElementById('diag-last-sync');
    if (syncEl) syncEl.innerText = timeString;

    // Field Counter
    const detailCount = Object.keys(data.details || {}).length;
    const matCount = (data.materialDetails || []).length;
    const fieldsEl = document.getElementById('diag-fields');
    if (fieldsEl) fieldsEl.innerText = detailCount + matCount;

    // Status Badges
    const sltBadge = document.getElementById('diag-slt-status');
    const erpBadge = document.getElementById('diag-erp-status');

    if (sltBadge) {
        if (data.url && data.url.includes('slt.lk')) {
            sltBadge.className = 'status-badge bg-green';
            sltBadge.innerText = 'CONNECTED';
        } else {
            sltBadge.className = 'status-badge bg-red';
            sltBadge.innerText = 'DISCONNECTED';
        }
    }

    if (erpBadge) {
        erpBadge.className = data.soNum ? 'status-badge bg-green' : 'status-badge bg-red';
        erpBadge.innerText = data.soNum ? 'DETECTED' : 'NOT FOUND';
    }
}

function renderEmptyState(status, list) {
    status.innerText = "Detecting SLT Portal...";
    status.style.color = "#94a3b8";
    list.innerHTML = `
        <div style="text-align:center; padding:40px 20px; color:#94a3b8;">
            <div style="font-size:32px; margin-bottom:15px;">📡</div>
            <div style="font-size:11px; font-weight:bold;">WAITING FOR DATA</div>
            <div style="font-size:10px; margin-top:5px; opacity:0.8;">Open a Service Order page on the SLT Portal to begin sync.</div>
        </div>
    `;

    const elements = ['diag-slt-status', 'diag-erp-status', 'diag-last-sync', 'diag-fields'];
    elements.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            if (id.includes('status')) { el.className = 'status-badge bg-red'; el.innerText = 'STANDBY'; }
            else el.innerText = '-';
        }
    });
}
