/**
 * SLT-ERP Bridge v2.4.1 "ULTRON-NUWARA-FIX"
 * Engine: Robust Hybrid Heuristics
 * Fix: Added Strict Priority Label Check to capture locations like Nuwara Eliya
 */

console.log('%c🔥 [SLT-ULTRON-NUWARA] v2.4.1 Initializing...', 'color: #ef4444; font-weight: bold; font-size: 16px;');

const VERSION = '2.4.1';

const CONFIG = {
    // Added REGION and EXCHANGE to help capture Nuwara Eliya details
    PRIORITY_LABELS: ['RTOM', 'SERVICE ORDER', 'CIRCUIT', 'SERVICE', 'RECEIVED DATE', 'CUSTOMER NAME', 'CONTACT NO', 'ADDRESS', 'STATUS', 'PACKAGE', 'TEAM', 'SERIAL', 'ONT', 'IPTV', 'MATERIAL', 'REGION', 'EXCHANGE', 'DISTRICT', 'TOWN', 'AREA'],
    JUNK: [/1769/i, /WELCOME/i, /LOGOUT/i, /WARNING/i, /CLICK HERE/i, /DASHBOARD/i]
};

let MASTER_GLUE = { so: '', tabs: {}, lastHash: '' };

const CoreUtils = {
    clean: (t) => t ? t.replace(/\s+/g, ' ').trim() : '',

    isCyanish: (el) => {
        try {
            const style = window.getComputedStyle(el);
            const color = style.color;
            if (!color) return false;
            // Cyan Checks
            if (color === 'rgb(13, 202, 240)' || color === 'rgb(0, 202, 240)' || color.includes('0dcaf0')) return true;
            const m = color.match(/\d+/g);
            if (m && m.length >= 3) {
                const r = parseInt(m[0]), g = parseInt(m[1]), b = parseInt(m[2]);
                return g > 130 && b > 130 && r < 160;
            }
        } catch (e) { return false; }
        return false;
    },

    isJunk: (t) => {
        if (!t || t.length < 1) return true;
        return CONFIG.JUNK.some(p => p.test(t));
    },

    getValue: (el) => {
        if (!el) return '';
        if (el.tagName === 'SELECT') return el.options[el.selectedIndex]?.text || '';
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return el.value || '';

        // Check for internal inputs
        const inner = el.querySelector('input, select');
        if (inner) return CoreUtils.getValue(inner);

        return CoreUtils.clean(el.innerText || el.textContent);
    }
};

class UltronHarvester {
    static run() {
        const results = { details: {}, materials: [], visuals: [] };
        const activeTab = this.getTab();

        // PHASE 1: HYBRID SCAN (Cyan + Bold + **PRIORITY LABELS**)
        document.querySelectorAll('label, b, strong, th, span, td, div').forEach(el => {
            const text = CoreUtils.clean(el.innerText);
            if (!text || text.length > 80 || CoreUtils.isJunk(text)) return;

            const style = window.getComputedStyle(el);
            const cleanKey = text.replace(':', '').toUpperCase();

            // FIX: We now check if the text matches a Priority Label, REGARDLESS of color/bold
            const isPriority = CONFIG.PRIORITY_LABELS.includes(cleanKey);
            const isVisualLabel = CoreUtils.isCyanish(el) || (style.fontWeight >= 700 && text.endsWith(':'));

            const isLabel = isPriority || isVisualLabel;

            if (isLabel) {
                const k = cleanKey;
                let v = '';

                // PROXIMITY SEARCH: Nearest valid node
                let next = el.nextElementSibling || el.nextSibling;
                while (next && (next.nodeType === 3 && !next.textContent.trim())) next = next.nextSibling;

                if (next) v = CoreUtils.getValue(next);

                // CROSS-CELL SEARCH (TD pair)
                if (!v || v === text) {
                    const td = el.closest('td');
                    if (td?.nextElementSibling) v = CoreUtils.getValue(td.nextElementSibling);
                }

                // PARENT VALUE SEARCH (If inside a div, check next sibling div)
                if (!v || v === text) {
                    const parent = el.parentElement;
                    if (parent && parent.nextElementSibling) {
                        v = CoreUtils.getValue(parent.nextElementSibling);
                    }
                }

                if (v && v !== text && !CoreUtils.isJunk(v)) {
                    results.details[k] = v;
                }
            }
        });

        // PHASE 2: MATRIX TABLE SCAN (Serials & Materials)
        document.querySelectorAll('table').forEach(table => {
            const rows = Array.from(table.querySelectorAll('tr'));
            if (rows.length < 1) return;
            const headers = Array.from(rows[0].querySelectorAll('td, th')).map(c => CoreUtils.clean(c.innerText).toUpperCase());

            rows.forEach((r, idx) => {
                const cells = Array.from(r.querySelectorAll('td, th'));

                // Vertical tables (2 cells row)
                if (cells.length === 2 && idx > 0) {
                    const k = CoreUtils.clean(cells[0].innerText).toUpperCase();
                    const v = CoreUtils.getValue(cells[1]);

                    // Force check priority keys here too
                    const isKeyImportant = CONFIG.PRIORITY_LABELS.includes(k);

                    if (k && v && v !== k && !CoreUtils.isJunk(k) && (isKeyImportant || !CoreUtils.isJunk(v))) {
                        results.details[k] = v;
                    }
                }

                // Grid matrices (Materials/Serials)
                const itemIdx = headers.findIndex(h => h.includes('ITEM') || h.includes('ATTRIBUTE') || h.includes('DESCRIPTION'));
                const valIdx = headers.findIndex(h => h.includes('QTY') || h.includes('VALUE') || h.includes('SERIAL') || h.includes('DEFAULT'));

                if (itemIdx !== -1 && valIdx !== -1 && idx > 0 && cells.length > Math.max(itemIdx, valIdx)) {
                    const itm = CoreUtils.clean(cells[itemIdx].innerText);
                    const val = CoreUtils.getValue(cells[valIdx]);
                    if (itm && val && !CoreUtils.isJunk(itm)) {
                        if (headers[itemIdx].includes('ITEM')) results.materials.push({ ITEM: 'MATERIAL', TYPE: itm, QTY: val });
                        else results.details[itm.toUpperCase()] = val;
                    }
                }
            });
        });

        // PHASE 3: VISUAL EXTRACTION
        if (activeTab.includes('IMAGE') || activeTab.includes('PHOTO')) {
            document.querySelectorAll('img').forEach(img => {
                const src = img.src || img.dataset.src;
                if (src && src.startsWith('http')) results.visuals.push({ url: src, alt: img.alt });
            });
        }

        return results;
    }

    static getTab() {
        const el = document.querySelector('.nav-tabs .nav-link.active') || document.querySelector('.active a');
        return el ? CoreUtils.clean(el.innerText).toUpperCase() : 'GENERAL';
    }
}

async function syncHeartbeat() {
    if (!chrome.runtime?.id) return;
    const url = window.location.href;
    const soMatch = url.match(/[?&]sod=([A-Z0-9]+)/i);
    const so = soMatch ? soMatch[1].toUpperCase() : '';

    // Allow running even if SO is not in URL for testing Nuwara Eliya pages, 
    // but usually we want SO. If you want to capture without SO, comment out the next line.
    // if (!so) return; 

    if (so !== MASTER_GLUE.so) {
        const saved = await new Promise(r => chrome.storage.local.get([`sod_${so}`], r));
        MASTER_GLUE.so = so;
        MASTER_GLUE.tabs = saved[`sod_${so}`] || {};
    }

    const currentTab = UltronHarvester.getTab();
    const result = UltronHarvester.run();

    // SMART PERSISTENCE
    if (Object.keys(result.details).length > 0 || result.materials.length > 0) {
        MASTER_GLUE.tabs[currentTab] = { ...(MASTER_GLUE.tabs[currentTab] || {}), ...result.details };

        // If visuals found
        if (result.visuals.length > 0) {
            if (!MASTER_GLUE.tabs['GALLERY']) MASTER_GLUE.tabs['GALLERY'] = [];
            result.visuals.forEach(v => {
                if (!MASTER_GLUE.tabs['GALLERY'].find(x => x.url === v.url)) MASTER_GLUE.tabs['GALLERY'].push(v);
            });
        }
    }

    const payload = {
        url: url,
        soNum: so,
        activeTab: currentTab,
        timestamp: new Date().toISOString(),
        details: result.details,
        allTabs: MASTER_GLUE.tabs,
        teamDetails: { 'SELECTED TEAM': CoreUtils.getValue(document.querySelector('#mobusr')) },
        materialDetails: result.materials,
        visualDetails: result.visuals,
        currentUser: CoreUtils.clean(document.querySelector('.user-profile-dropdown h6')?.innerText || "").replace("Welcome, ", "")
    };

    const hash = btoa(JSON.stringify(payload.allTabs) + JSON.stringify(payload.materialDetails)).substring(0, 32);
    if (hash !== MASTER_GLUE.lastHash) {
        MASTER_GLUE.lastHash = hash;
        chrome.storage.local.set({ lastScraped: payload, [`sod_${so}`]: MASTER_GLUE.tabs });

        // Send message to background (safe wrapper)
        try {
            chrome.runtime.sendMessage({ action: 'pushToERP', data: payload });
        } catch (e) {
            console.log("Runtime message failed (background not ready yet, likely on first load)");
        }
    }
}

// Global Reaction Engine
new MutationObserver(() => {
    // Debounce slightly to prevent freezing on heavy pages
    if (window.ultronTimeout) clearTimeout(window.ultronTimeout);
    window.ultronTimeout = setTimeout(syncHeartbeat, 500);
}).observe(document.body, { childList: true, subtree: true });

// UI INDICATOR
if (!document.getElementById('ultron-meta')) {
    const b = document.createElement('div');
    b.id = 'ultron-meta';
    b.style.cssText = `position: fixed; top: 10px; right: 20px; z-index: 999999; background: #ef4444; color: #fff; padding: 4px 12px; border-radius: 4px; font-family: monospace; font-size: 11px; font-weight: bold; box-shadow: 0 4px 10px rgba(239,68,68,0.5); pointer-events: none;`;
    b.innerHTML = `ULTRON-NUWARA v${VERSION}`;
    document.body.appendChild(b);
}

syncHeartbeat();
setInterval(syncHeartbeat, 3000);