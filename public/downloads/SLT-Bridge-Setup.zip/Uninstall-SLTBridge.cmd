@echo off
rem Removes the SLT-ERP Bridge force-install entry again - Chrome and Edge drop the
rem extension on their next full restart. Only the bridge entry is deleted, any other
rem extension an IT department enforces is left exactly as it was.
if not exist "%~dp0Install-SLTBridge.ps1" (
    echo Install-SLTBridge.ps1 has to stay next to this file.
    pause
    exit /b 2
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-SLTBridge.ps1" -Uninstall %*
exit /b %errorlevel%
