@echo off
rem One-click SLT-ERP Bridge installer for Chrome and Edge - no Developer mode,
rem no zip extracting, nothing to click on chrome://extensions.
rem
rem It runs Install-SLTBridge.ps1 sitting next to it. That script asks Windows for
rem administrator once, because since Windows 11 24H2 the browser policy keys are
rem read-only for a standard token, and then writes the force-install entry that
rem makes Chrome/Edge download and install the bridge themselves.
rem
rem Fleet use: push this from SCCM, Intune or a GPO startup script. Those run as
rem SYSTEM, so no prompt appears at all. Call the ps1 with -Hive machine to install
rem it for every user of the box instead of only the current one.
rem
rem Extra arguments go straight to the ps1, e.g. -NoElevate, -WhatIf, -Hive machine.
if not exist "%~dp0Install-SLTBridge.ps1" (
    echo Install-SLTBridge.ps1 has to stay next to this file.
    pause
    exit /b 2
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-SLTBridge.ps1" %*
rem Hand the real result back so Intune/SCCM can tell success from a declined UAC.
exit /b %errorlevel%
