<#
.SYNOPSIS
    Standalone SLT-ERP Bridge installer for Chrome and Edge - no Developer mode,
    no repository checkout.

.DESCRIPTION
    Writes the ExtensionInstallForcelist policy that makes Chrome and Edge install
    the bridge silently on next start. The browser itself downloads the signed
    CRX3 from the ERP origin over HTTPS, so nothing is copied around per machine
    and the extension keeps updating whenever the ERP is redeployed.

    One elevation is required. Since Windows 11 24H2/25H2 the whole
    HKCU\Software\Policies subtree is owned by SYSTEM with ReadKey only for the
    signed-in user, so even the per-user hive cannot be written from a standard
    token. The script therefore relaunches itself once through UAC (-NoElevate
    suppresses that when an IT tool already runs it elevated, e.g. SCCM/Intune in
    SYSTEM context or a GPO logon script running as admin).

    Existing force-install entries (values named 1..n) are never overwritten: a
    free numbered slot from -StartSlot upwards is used, so a machine that already
    enforces other extensions is left intact.

    Remove everything again with -Uninstall. Both operations only touch the two
    policy keys below - no other browser setting and no files anywhere.

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File Install-SLTBridge.ps1
.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File Install-SLTBridge.ps1 -WhatIf
.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File Install-SLTBridge.ps1 -Hive machine
.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File Install-SLTBridge.ps1 -Uninstall
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string] $ExtensionId = 'mhbnhnpammnagfmgomcpakeeohbnkajm',
    [string] $UpdateManifest = 'https://sltserp.vercel.app/slt-bridge-updates.xml',
    [ValidateSet('chrome', 'edge', 'all')] [string] $Browser = 'all',
    [ValidateRange(1, 999)] [int] $StartSlot = 90,
    # user = current logon only, machine = every user on it (what IT usually wants)
    [ValidateSet('user', 'machine')] [string] $Hive = 'user',
    [switch] $NoElevate,
    [switch] $Pause,
    [switch] $Uninstall
)

$ErrorActionPreference = 'Stop'

$HiveRoot = if ($Hive -eq 'machine') { 'HKLM:' } else { 'HKCU:' }
$Hives = [ordered]@{
    chrome = "$HiveRoot\Software\Policies\Google\Chrome"
    edge   = "$HiveRoot\Software\Policies\Microsoft\Edge"
}

function Test-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    return ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-BrowserInstalled {
    param([string]$Name)
    $paths = switch ($Name) {
        chrome { @(
            "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
            "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
            "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") }
        edge   { @(
            "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
            "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") }
    }
    return [bool]($paths | Where-Object { $_ -and (Test-Path $_) })
}

function Get-NumericValues {
    param([string]$Hive)
    if (-not (Test-Path $Hive)) { return @() }
    $names = Get-Item -Path $Hive | ForEach-Object { $_.GetValueNames() } | Where-Object { $_ -match '^\d+$' }
    return @($names | ForEach-Object {
        [pscustomobject]@{ Name = $_; Data = (Get-ItemProperty -Path $Hive -Name $_).$_ }
    })
}

function Install-Forced {
    param([string]$Name, [string]$Entry)
    $hive = $Hives[$Name]
    $current = Get-NumericValues -Hive $hive

    if ($current.Data -contains $Entry) {
        Write-Host "  [$Name]  already enforced (slot $(@($current | Where-Object Data -eq $Entry).Name))" -ForegroundColor DarkGray
        return
    }
    $taken = @($current.Name | ForEach-Object { [int]$_ })
    $slot = $StartSlot
    while ($taken -contains $slot) { $slot++ }

    if ($PSCmdlet.ShouldProcess($hive, 'force-install SLT-ERP Bridge')) {
        try {
            if (-not (Test-Path $hive)) { New-Item -Path $hive -Force | Out-Null }
            New-ItemProperty -Path $hive -Name "$slot" -Value $Entry -PropertyType String -Force | Out-Null
        }
        catch {
            Report-Denied -Name $Name -Hive $hive -What 'write'
            $script:Failed = $true
            return
        }
        Write-Host "  [$Name]  enforced in slot $slot" -ForegroundColor Green
    }
}

function Uninstall-Forced {
    param([string]$Name)
    $hive = $Hives[$Name]
    $mine = @(Get-NumericValues -Hive $hive | Where-Object { $_.Data -like "$ExtensionId;*" })
    if (-not $mine) {
        Write-Host "  [$Name]  nothing to remove" -ForegroundColor DarkGray
        return
    }
    foreach ($m in $mine) {
        if ($PSCmdlet.ShouldProcess("$hive\$($m.Name)", 'remove force-install')) {
            try { Remove-ItemProperty -Path $hive -Name $m.Name }
            catch {
                Report-Denied -Name $Name -Hive $hive -What 'remove'
                $script:Failed = $true
                return
            }
            Write-Host "  [$Name]  removed slot $($m.Name): $($m.Data)" -ForegroundColor Green
        }
    }
}

function Report-Denied {
    param([string]$Name, [string]$Hive, [string]$What)
    Write-Host "  [$Name]  access denied - this token cannot $What $Hive" -ForegroundColor Red
    Write-Host '           Windows locks both policy hives for a standard user, so run the' -ForegroundColor DarkGray
    Write-Host '           .cmd launcher (it asks for UAC once) or have IT push the entry to' -ForegroundColor DarkGray
    Write-Host '           HKLM from SCCM/Intune, which runs as SYSTEM and is allowed.' -ForegroundColor DarkGray
}

$targets = if ($Browser -eq 'all') { @('chrome', 'edge') } else { @($Browser) }
$found = @($targets | Where-Object { Test-BrowserInstalled $_ })
if ($Browser -eq 'all' -and -not $found) { $found = $targets }
if (-not $found) {
    Write-Warning 'No Chrome or Edge installation was found on this machine.'
    return
}

$entry = "$ExtensionId;$UpdateManifest"

# One administrator prompt is unavoidable: since Windows 11 24H2 the whole
# HKCU\Software\Policies subtree is ReadKey-only for the signed-in user, so the
# per-user hive needs the same elevation the machine hive does. Relaunching with
# -NoElevate is what stops this from turning into a prompt loop.
if (-not $NoElevate -and -not $WhatIfPreference -and -not (Test-IsAdmin)) {
    Write-Host ''
    Write-Host '  One UAC prompt is coming - Windows will not let a standard token' -ForegroundColor Yellow
    Write-Host '  write any browser policy key, not even under HKCU.' -ForegroundColor Yellow
    $relaunch = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"",
        '-ExtensionId', $ExtensionId, '-UpdateManifest', $UpdateManifest,
        '-Browser', $Browser, '-StartSlot', $StartSlot, '-Hive', $Hive, '-NoElevate', '-Pause')
    if ($Uninstall) { $relaunch += '-Uninstall' }
    try {
        Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $relaunch -Verb RunAs | Out-Null
        Write-Host '  Relaunched elevated - finish it in the window that just opened.' -ForegroundColor Green
    }
    catch {
        Write-Error "Elevation declined, nothing was changed. Run it as administrator, or let IT push it: $($_.Exception.Message)"
        exit 1
    }
    return
}

$script:Failed = $false

if (-not $Uninstall -and $UpdateManifest -notmatch '^https://') {
    # Chrome refuses a self-hosted force install that is not fetched over HTTPS.
    Write-Warning "-UpdateManifest should be an https:// URL or Chrome will ignore it."
}

Write-Host ''
Write-Host ('=== SLT-ERP Bridge {0} ({1} policy) ===' -f $(if ($Uninstall) { 'removal' } else { 'force-install' }), $Hive) -ForegroundColor Cyan
Write-Host "  target: $entry" -ForegroundColor White
Write-Host "  browsers: $($found -join ', ')" -ForegroundColor DarkGray
Write-Host ''

foreach ($name in $found) {
    if ($Uninstall) { Uninstall-Forced -Name $name } else { Install-Forced -Name $name -Entry $entry }
}

Write-Host ''
if ($script:Failed) {
    Write-Host '  Nothing was changed for the browsers marked in red above.' -ForegroundColor Red
}
elseif ($Uninstall) {
    Write-Host '  Close the browser completely and reopen it - the extension disappears.' -ForegroundColor Green
}
else {
    Write-Host '  Last step (needed once):' -ForegroundColor Yellow
    Write-Host '   1. Close EVERY browser window (tray icons too), then reopen.'
    Write-Host '   2. Open chrome://policy  (or edge://policy) and click "Reload policies".'
    Write-Host '   3. chrome://extensions now lists "SLT-ERP Bridge - Installed by enterprise policy".'
    Write-Host ''
    Write-Host '  The browser will say it is managed by your organisation. Roll back any time with' -ForegroundColor DarkGray
    Write-Host '  Uninstall-SLTBridge.cmd (or this script with -Uninstall).' -ForegroundColor DarkGray
}
Write-Host ''
if ($Pause) { Read-Host 'Press ENTER to close this window' | Out-Null }
if ($script:Failed) { exit 1 }
